<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'assignsubmission_snap', language 'es', version '4.5'.
 *
 * @package     assignsubmission_snap
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['cloud'] = 'Utilización del "cloud" de Snap!';
$string['cloud_enable'] = 'Habilita el "cloud"';
$string['cloud_help'] = 'Moodle puede habilitar/deshabilitar las funcionalidades de "cloud" de Snap! y, si se habilitan, cada tarea puede individualmente habilitarlas o no.';
$string['cloud_helpbutton'] = 'Habilita/deshabilita el cloud de Snap!.';
$string['cloud_helpbutton_help'] = 'Habilita/deshabilita el cloud de Snap!. Este selector puede estar deshabilitado per el administrador para impedir el uso del "cloud" de Snap! en todo el entorno.';
$string['cloud_op_bydefault'] = 'Características de Snap! cloud habilitadas y seleccionadas por defecto';
$string['cloud_op_disabled'] = 'Características de Snap! cloud deshabilitadas';
$string['cloud_op_enabled'] = 'Snap! cloud habilitat però no seleccionat per defecte';
$string['default'] = 'Seleccionado por defecto en las nuevas tareas';
$string['default_help'] = 'Si está marcado, este tipo de envío se seleccionará por defecto en las nuevas tareas.';
$string['distros'] = 'Distribuciones de Snap! habilitadas';
$string['distros_help'] = 'Se necesita una distribución funcional (como  Snap!-Berkeley, la opción que viene por defecto).
    Pero se pueden añadir más (una por línea) y el profesorado podrá escoger la que necesite individualmente en cada tarea.
    El formato (para cada entrada) es: <b>&lt;código&gt; | &lt;nombre visible&gt; | &lt;url&gt;</b>.
    Hay que mantener el parámetro "código" al hacer cambios (url...) para mantener su correspondencia con las tareas anteriores.
    La primera distro es la opción por defecto para las nuevas tareas y para aquellas con distro deshabilitada.';
$string['enabled'] = 'Snap!';
$string['enabled_help'] = 'Si está habilitado, los estudiantes podrán editar y enviar proyectos de Snap! en los envíos.
    Si un proyecto de Snap! en formato XML se adjunta en la sección de "Archivos adicionales", éste será utilitzado como plantilla (punto de salida) de los estudiantes
    cuando se inicia un nuevo envío. Si no, tendrán inicialmente un proyecto nuevo (vacío) de Snap!.';
$string['eventassessableuploaded'] = 'Contenido de Snap! cargado.';
$string['lang_helpbutton'] = 'Configuración del idioma en Snap!';
$string['lang_helpbutton_help'] = 'Si se selecciona, Snap! utilitzará el mismo idioma que en Moodle (el definido por el curso o por el usuario de Moodle).';
$string['langmoodle'] = 'Utiliza el mismo idioma que en Moodle';
$string['langsnap'] = 'Idioma en Snap!';
$string['pluginname'] = 'Envíos de Snap!';
$string['privacy:metadata:assignmentid'] = 'ID del envío';
$string['privacy:metadata:submissionpurpose'] = 'La ID del envío que enlaza con los envíos del usuario.';
$string['privacy:metadata:tablepurpose'] = 'Guarda el envío de Snap! de cada intento.';
$string['privacy:metadata:textpurpose'] = 'El proyecto actual de Snap! enviado en este intento de la tarea.';
$string['privacy:path'] = 'proyecto de Snap!';
$string['snap'] = 'Snap!';
$string['snap_embedded'] = 'Snap! en Moodle';
$string['snap_project'] = 'Área de proyecto';
$string['snap_readonlywarning'] = 'MODO DE LECTURA';
$string['snapdistro'] = 'Snap! distro';
$string['snapdistro_helpbutton'] = 'Escoge la distribución de Snap!';
$string['snapdistro_helpbutton_help'] = 'Escoge la distribución de Snap! que necesitas para esta tarea. Las personas administradoras de este Moodle pueden añadir-editar-quitar las distibuciones disponibles.';
$string['snapfilename'] = 'snapproject.xml';

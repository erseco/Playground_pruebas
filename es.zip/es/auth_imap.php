<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'auth_imap', language 'es', version '4.5'.
 *
 * @package     auth_imap
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['auth_imapchangepasswordurl_key'] = 'URL  de cambio de contraseña';
$string['auth_imapdescription'] = 'Este método usa un servidor IMAP para comprobar si el nombre de usuario y contraseña son válidos.';
$string['auth_imaphost'] = 'Dirección del servidor IMAP. Use el número IP, no el nombre DNS.';
$string['auth_imaphost_key'] = 'Host';
$string['auth_imapnotinstalled'] = 'No se puede usar la identificación IMAP. El módulo IMAP de PHP no está instalado.';
$string['auth_imapport'] = 'Número del puerto del servidor IMAP. Normalmente es 143 o 993.';
$string['auth_imapport_key'] = 'Puerto';
$string['auth_imaptype'] = 'Tipo de servidor IMAP. Los servidores IMAP pueden tener diferentes tipos de identificación y negociación.';
$string['auth_imaptype_key'] = 'Tipo';
$string['pluginname'] = 'Usar un servidor IMAP';
$string['privacy:metadata'] = 'El plugin de Autenticación por servidor IMAP no almacena ningun dato personal.';

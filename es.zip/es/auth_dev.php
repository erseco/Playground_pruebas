<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'auth_dev', language 'es', version '4.5'.
 *
 * @package     auth_dev
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['auth_devdescription'] = 'Esta herramienta es sólo para propósitos de desarrollo con el fin de ayudar a Desarrolladores y Administradores Principales';
$string['config_enablelogouturl'] = 'Habilitar una URL de redirección tras cierre de sesión';
$string['config_enablelogouturl_description'] = 'Si esta opción está habilitada CUALQUIER usuario será redirigido cuando cierre sesión.';
$string['config_logouturl'] = 'URL de redirección tras cierre de sesión';
$string['pluginname'] = 'Herramientas de desarrollo de autenticación';
$string['privacy:metadata'] = 'El plugin de herramientas de Desarrollo de Autenticación no almacena ningún dato personal.';

//
// This file is part of Adaptable theme for moodle
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

//
// Adaptable alerts JS file
//
// @package    local_adaptable
// @copyright  2015-2019 Jeremy Hopkins (Coventry University)
// @copyright  2015-2019 Fernando Acedo (3-bits.com)
// @copyright  2018-2019 Manoj Solanki (Coventry University)
// @copyright  2023 G J Barnard
//               {@link https://moodle.org/user/profile.php?id=442195}
//               {@link https://gjbarnard.co.uk}
// @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later.
//

import $ from 'jquery';
import { setUserPreference } from 'local_adaptable/util';
import log from 'core/log';


/**
 * Alerts.
 */
const alerts = () => {
    /* Dismiss Alerts
       Bootstrap will close the alert because it spots the data-dismiss="alert" attribute
       Here we also handle the alert close event. We have added two custom tags data-alertindex
       and data-alertkey. e.g Alert1  has alertindex1. The alertkey value identifies the
       alert content, since Alert1 (2 and 3) will be reused. We use a YUI function to set
       the user preference for the key to the last dismissed key for the alertindex.
       alertkey undismissable is a special case for "loginas" alert which shouldn't really
       be permanently dismissed.
       Justin 2015/12/05. */

    $('.customalert .close').click(function () {
        var alertindex = $(this).data('alertindex');
        var alertkey = $(this).data('alertkey');
        if (alertkey != 'undismissable' && alertkey != 'undefined' && alertkey) {
            setUserPreference('theme_adaptable_alertkey' + alertindex, alertkey);
            log.debug('Local Adaptable Alert index \'' + alertindex + '\' and key \'' + alertkey + '\' dismissed');
        }
    });
};

/**
 * Set up the alerts.
 */
export const init = () => {
    log.debug('Local Adaptable ES6 Alerts');
    if (document.readyState !== 'loading') {
        log.debug("Local Adaptable ES6 Alerts init DOM content already loaded");
        alerts();
    } else {
        log.debug("Local Adaptable ES6 Alerts init JS DOM content not loaded");
        document.addEventListener('DOMContentLoaded', function () {
            log.debug("Local Adaptable ES6 Alerts init JS DOM content loaded");
            alerts();
        });
    }
};

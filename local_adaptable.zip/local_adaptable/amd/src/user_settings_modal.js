// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

//
// User settings modal.
//
// @module     local_adaptable/user_settings_modal
// @copyright  2024 G J Barnard.
// @author     G J Barnard -
//               {@link https://moodle.org/user/profile.php?id=442195}
//               {@link https://gjbarnard.co.uk}
// @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later.
//

import {setUserPreferences} from 'core_user/repository';
import log from 'core/log';
import Notification from 'core/notification';

/**
 * Settings.
 */
const settings = () => {
    const usermysitessortoverrideselect = document.getElementById("usermysitessortoverrideselect");
    var usermysitessortoverrideselectchanged = false;

    if (usermysitessortoverrideselect) {
        usermysitessortoverrideselect.addEventListener("change", function() {
            usermysitessortoverrideselectchanged = true;
        });
    }

    const userfavmenutitle = document.getElementById("userfavmenutitle");
    var userfavmenutitlechanged = false;
    if (userfavmenutitle) {
        userfavmenutitle.addEventListener("change", function() {
            userfavmenutitlechanged = true;
        });
        userfavmenutitle.addEventListener("keyup", function() {
            userfavmenutitlechanged = true;
        });
    }

    const userfavmenu = document.getElementById("userfavmenu");
    var userfavmenuchanged = false;
    if (userfavmenu) {
        userfavmenu.addEventListener("change", function() {
            userfavmenuchanged = true;
        });
        userfavmenu.addEventListener("keyup", function() {
            userfavmenuchanged = true;
        });
    }

    // Update preferences.
    const updatePrefs = async () => {
        let preferences = [];

        if (usermysitessortoverrideselectchanged) {
            preferences.push({
                userid: 0, // Current user.
                name: 'local_adaptable_user_mysitessortoverride',
                value: usermysitessortoverrideselect.value
            });
        }

        if (userfavmenutitlechanged) {
            preferences.push({
                userid: 0,
                name: 'local_adaptable_user_userfavmenutitle',
                value: userfavmenutitle.value
            });
        }

        if (userfavmenuchanged) {
            preferences.push({
                userid: 0,
                name: 'local_adaptable_user_userfavmenu',
                value: userfavmenu.value
            });
        }

        if (preferences.length != 0) {
            try {
                await setUserPreferences(preferences);
                usermysitessortoverrideselectchanged = false;
                userfavmenutitlechanged = false;
                userfavmenuchanged = false;
            } catch (err) {
                Notification.exception(err);
            }
        }
    };

    // Save button.
    const usersettingsmodalsave = document.getElementById("usersettingsmodalsave");
    usersettingsmodalsave.addEventListener("click", function() {
        updatePrefs();
    });

    // Reload button.
    const usersettingsmodalreload = document.getElementById("usersettingsmodalreload");
    usersettingsmodalreload.addEventListener("click", function(e) {
        updatePrefs().then(() => {
            window.location = e.target.dataset.url;
        });
    });
};

/**
 * Init.
 */
export const init = () => {
    log.debug('Local Adaptable User Settings Modal ES6 init');
    if (document.readyState !== 'loading') {
        log.debug("Local Adaptable User Settings Modal ES6 init DOM content already loaded");
        settings();
    } else {
        log.debug("Local Adaptable User Settings Modal ES6 init JS DOM content not loaded");
        document.addEventListener('DOMContentLoaded', function () {
            log.debug("Local Adaptable Settings Modal ES6 init JS DOM content loaded");
            settings();
        });
    }
};

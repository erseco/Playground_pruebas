Adaptable local
===============

Required release of Moodle
==========================
This release works with Moodle 4.5 version 2024100700.00 (Build: 20241007) and above within the MOODLE_405_STABLE branch .

Please ensure that your hardware and software complies with 'Requirements' in 'Installing Moodle' on
'https://docs.moodle.org/405/en/Installing_Moodle'.

Installation
============
 1. Ensure you have the release of Moodle as stated above in 'Required release of Moodle'.  This is essential as the
    plugin relies on underlying core code that is out of my control.
 2. Login as an administrator and put Moodle in 'Maintenance Mode' so that there are no users using it bar you as the administrator.
 3. Rename the extracted (from the zip file) 'moodle-local_adaptable-main' folder to 'adaptable'.
 4. Copy the 'adaptable' folder to the '/local/' folder.
 5. Go to 'Site administration' -> 'Notifications' and follow standard the 'plugin' update notification.
 6. Put Moodle out of Maintenance Mode.

Upgrading
=========
 1. Ensure you have the release of Moodle as stated above in 'Required release of Moodle'.  This is essential as the
    plugin relies on underlying core code that is out of my control.
 2. Login as an administrator and put Moodle in 'Maintenance Mode' so that there are no users using it bar you as the administrator.
 3. Make a backup of your old 'adaptable' folder in '/local/' and then delete the folder.
 4. Rename the extracted (from the zip file) 'moodle-local_adaptable-main' folder to 'adaptable'.
 5. Copy the replacement extracted 'adaptable' folder to the '/local/' folder.
 6. Go to 'Site administration' -> 'Notifications' and follow standard the 'plugin' update notification.
 7. Put Moodle out of Maintenance Mode.

Uninstallation
==============
 1. Put Moodle in 'Maintenance Mode' so that there are no users using it bar you as the administrator.
 2. In '/local/' remove the folder 'adaptable'.
 3. Go to 'Site administration' -> 'Notifications' and follow standard the 'plugin' update notification.
 4. Put Moodle out of Maintenance Mode.

Versioning
==========
Adaptable is maintained under the Semantic Versioning 2.0.0 guidelines as much as possible. Releases will be numbered with the
following format:

major.minor.patch

and following these guidelines:

- Breaking backward compatibility bumps the major (and resets the minor and patch)
- New additions without breaking backward compatibility bumps the minor (and resets the patch)
- Bug fixes and misc changes bumps the patch

For more information on SemVer, please visit http://semver.org.

Licenses
========
Local Adaptable is licensed under:

- [GPL v3 (GNU General Public License)](http://www.gnu.org/licenses)

Version Information
===================
See Changes.md

Me
==
G J Barnard MSc. BSc(Hons)(Sndw). MBCS. CEng. CITP. PGCE.
Moodle profile: https://moodle.org/user/profile.php?id=442195
Web profile   : https://gjbarnard.co.uk
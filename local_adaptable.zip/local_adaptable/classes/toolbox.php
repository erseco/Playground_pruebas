<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Toolbox.
 *
 * @package    local_adaptable
 * @copyright  2023 G J Barnard
 *               {@link https://moodle.org/user/profile.php?id=442195}
 *               {@link https://gjbarnard.co.uk}
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later.
 */

namespace local_adaptable;

use stdClass;

/**
 * Class definition for toolbox.
 */
class toolbox {
    /**
     * @var toolbox Singleton instance of us.
     */
    private static $instance = null;

    /**
     * @var alerts Singleton instance of alerts.
     */
    private static $alerts = null;

    /**
     * @var categoryheaders Singleton instance of category_headers.
     */
    private static $categoryheaders = null;

    /**
     * @var login Singleton instance of login.
     */
    private static $login = null;

    /**
     * Gets the toolbox singleton.
     *
     * @return toolbox The toolbox instance.
     */
    public static function get_instance() {
        if (!is_object(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Checks to see if the given methods are supported.
     *
     * @param array $methods Methods.
     *
     * returns Message if any are unsupported.
     */
    public function supported_methods($methods, $versionrequired) {
        $retr = '';
        $missingmethods = [];
        foreach ($methods as $method) {
            if (!method_exists($this, $method)) {
                $missingmethods[] = $method;
            }
        }
        if (!empty($missingmethods)) {
            $retr = get_string(
                'missingmethods',
                'local_adaptable',
                [
                    'methods' => implode(',', $missingmethods),
                    'versionrequired' => $versionrequired,
                ]
            );
        }
        return $retr;
    }

    /**
     * Returns custom JS if any.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     *
     * @return string Markup.
     */
    public function get_custom_js($settings, $page, $output) {
        $retr = '';
        if (class_exists('\\local_adaptable\\output\\custom_js')) {
            $customjs = new \local_adaptable\output\custom_js();
            $retr = $customjs->get_custom_js($settings, $page, $output);
        }
        return $retr;
    }

    /**
     * Generates elements of the login main content.
     *
     * @param string   $logincontent Login content.
     * @param stdClass $settings theme settings.
     *
     * return stdClass Header and Footer inclusion booleans.
     */
    public function generate_login(&$logincontent, $settings) {
        if (!is_object(self::$login)) {
            if (class_exists('\\local_adaptable\\output\\login')) {
                self::$login = new \local_adaptable\output\login();
            } else {
                $retr = new stdClass();
                $retr->header = '';
                $retr->footer = '';
                return $retr;
            }
        }
        return self::$login->generate_login($logincontent, $settings);
    }

    /**
     * Generates the login styles.
     *
     * @param theme_config $theme The theme config object.
     *
     * return stdClass style strings.
     */
    public function login_style($theme) {
        if (!is_object(self::$login)) {
            if (class_exists('\\local_adaptable\\output\\login')) {
                self::$login = new \local_adaptable\output\login();
            } else {
                $retr = new stdClass();
                $retr->loginbgimage = '';
                $retr->loginbgstyle = '';
                $retr->loginbgopacity = '';
                return $retr;
            }
        }
        return self::$login->login_style($theme);
    }

    /**
     * Returns list of alert messages for the user.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     *
     * @return string Markup if any.
     */
    public function get_alert_messages($settings, $page, $output) {
        if (!is_object(self::$alerts)) {
            if (class_exists('\\local_adaptable\\output\\alerts')) {
                self::$alerts = new \local_adaptable\output\alerts($page);
            } else {
                return '';
            }
        }
        return self::$alerts->get_alert_messages($settings, $page, $output);
    }

    /**
     * Displays notices to alert teachers of problems with course such as being hidden.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     *
     * @return string Markup if any.
     */
    public function get_course_alerts($settings, $page, $output) {
        if (!is_object(self::$alerts)) {
            if (class_exists('\\local_adaptable\\output\\alerts')) {
                self::$alerts = new \local_adaptable\output\alerts($page);
            } else {
                return '';
            }
        }
        return self::$alerts->get_course_alerts($settings, $page, $output);
    }

    /**
     * Returns the category header data required for header.php.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     *
     * @return array Current top level category and header backgound, if any.
     */
    public function get_category_header($settings, $page) {
        if (!is_object(self::$categoryheaders)) {
            if (class_exists('\\local_adaptable\\output\\category_headers')) {
                self::$categoryheaders = new \local_adaptable\output\category_headers();
            } else {
                return ['currenttopcat' => false, 'headerbg' => ''];
            }
        }
        return self::$categoryheaders->get_header($settings, $page);
    }

    /**
     * Sets the logo.
     *
     * @param bool/int $currenttopcat The id of the current top category or false if none.
     * @param stdClass $settings theme settings.
     * @return string $logosetarea the logo setting area.
     */
    public function get_logo($currenttopcat, &$logosetarea, $settings) {
        if (!is_object(self::$categoryheaders)) {
            if (class_exists('\\local_adaptable\\output\\category_headers')) {
                self::$categoryheaders = new \local_adaptable\output\category_headers();
            } else {
                return;
            }
        }
        return self::$categoryheaders->get_logo($currenttopcat, $logosetarea, $settings);
    }

    /**
     * Sets the custom title.
     *
     * @param bool/int $currenttopcat The id of the current top category or false if none.
     * @param stdClass $settings theme settings.
     * @param string $categoryheadercustomtitle the custom title.
     *
     * @return string The custom title, if any.
     */
    public function get_title($currenttopcat, &$categoryheadercustomtitle, $settings) {
        if (!is_object(self::$categoryheaders)) {
            if (class_exists('\\local_adaptable\\output\\category_headers')) {
                self::$categoryheaders = new \local_adaptable\output\category_headers();
            } else {
                return;
            }
        }
        return self::$categoryheaders->get_title($currenttopcat, $categoryheadercustomtitle, $settings);
    }

    /**
     * Adds any category custom SCSS to the SCSS before it is cached.
     *
     * @param string $css The original SCSS.
     * @param array $settings Theme settings.
     * @return string The SCSS which now contains our custom SCSS.
     */
    public function set_categorycustomcss($scss, $settings) {
        if (!is_object(self::$categoryheaders)) {
            if (class_exists('\\local_adaptable\\output\\category_headers')) {
                self::$categoryheaders = new \local_adaptable\output\category_headers();
            } else {
                return $scss;
            }
        }
        return self::$categoryheaders->set_categorycustomcss($scss, $settings);
    }

    /**
     * Creates the My Courses menu if enabled.
     *
     * @param custom_menu_item $menu The parent menu to add to.
     * @param int $branchsort Branch sort value to add to if the menu is added.
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     */
    public function get_mycourses(
        $menu,
        &$branchsort,
        $settings,
        $page,
        $output
    ) {
        if (class_exists('\\local_adaptable\\output\\my_courses')) {
            $mycourses = new \local_adaptable\output\my_courses();
            $mycourses->get_mycourses(
                $menu,
                $branchsort,
                $settings,
                $page,
                $output
            );
        }
    }

    /**
     * Renders the user settings.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     *
     * @return string Markup.
     */
    public function get_user_settings(
        $settings,
        $page,
        $output
    ) {

        if (!isloggedin()) {
            return '';
        }

        $retr = '';

        $items = [];
        if (class_exists('\\local_adaptable\\output\\my_courses')) {
            $mycourses = new \local_adaptable\output\my_courses();
            $item = $mycourses->render_user_mysitessortoverride_select(
                $settings,
                $output
            );
            if (!empty($item)) {
                $items[] = $item;
            }
        }

        if (class_exists('\\local_adaptable\\output\\userfav_menu')) {
            $userfavmenu = new \local_adaptable\output\userfav_menu();
            $item = $userfavmenu->render_user_fav_settings(
                $settings,
                $output
            );
            if (!empty($item)) {
                $items[] = $item;
            }
        }

        if (!empty($items)) {
            $templatecontext = new stdClass();
            $templatecontext->pageurl = $page->url->out(false);
            $templatecontext->items = $items;

            $retr = $output->render_from_template('local_adaptable/usersettingsmodal', $templatecontext);
        }

        return $retr;
    }

    /**
     * Returns html to render news ticker.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     *
     * @return string Markup.
     */
    public function get_news_ticker($settings, $page, $output) {
        if (class_exists('\\local_adaptable\\output\\news_ticker')) {
            $newsticker = new \local_adaptable\output\news_ticker();
            return $newsticker->get_news_ticker($settings, $page, $output);
        }
        return '';
    }

    /**
     * Returns html to render user favourites menu on the main navigation bar.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     *
     * @return string
     */
    public function userfav_menu($settings, $page, $output) {
        if (class_exists('\\local_adaptable\\output\\userfav_menu')) {
            $userfavmenu = new \local_adaptable\output\userfav_menu();
            return $userfavmenu->userfavmenu($settings, $page, $output);
        }
        return '';
    }

    /**
     * Returns array of custom menu items for the user favourites menu.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     *
     * @return array Of custom menu items.
     */
    public function userfav_menu_items($settings, $page, $output) {
        if (class_exists('\\local_adaptable\\output\\userfav_menu')) {
            $userfavmenu = new \local_adaptable\output\userfav_menu();
            return $userfavmenu->userfavmenuitems($settings, $page, $output);
        }
        return '';
    }

    /**
     * Returns html to render tools menu on the main navigation bar.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     * @param string $menuid The id to use when creating menu.  Used so this could be called for a nav drawer style display.
     *
     * @return string
     */
    public function tools_menu($settings, $page, $output, $menuid = '') {
        if (class_exists('\\local_adaptable\\output\\tools_menu')) {
            $toolsmenu = new \local_adaptable\output\tools_menu();
            return $toolsmenu->toolsmenu($settings, $page, $output, $menuid);
        }
        return '';
    }

    /**
     * Returns array of custom menu items for the tools menu(s).
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     *
     * @return array Of custom menu items.
     */
    public function tools_menu_items($settings, $page, $output) {
        if (class_exists('\\local_adaptable\\output\\tools_menu')) {
            $toolsmenu = new \local_adaptable\output\tools_menu();
            return $toolsmenu->toolsmenuitems($settings, $page, $output);
        }
        return [];
    }

    /**
     * Returns all tracking methods.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     *
     * @return string Markup.
     */
    public function get_all_tracking_methods($settings, $page, $output) {
        if (class_exists('\\local_adaptable\\output\\tracking')) {
            $tracking = new \local_adaptable\output\tracking();
            return $tracking->get_all_tracking_methods($settings, $page, $output);
        }
        return '';
    }

    /**
     * Instantiate a new instance of the user myprofile renderer.
     *
     * @param moodle_page $page
     * @param string $target
     *
     * @return Object instance.
     */
    public function get_userprofile_renderer(\moodle_page $page, $target) {
        if (class_exists('\\local_adaptable\\output\\core_user\\myprofile\\renderer')) {
            return new \local_adaptable\output\core_user\myprofile\renderer($page, $target);
        }
        return null;
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Provider class file.  As required for any data privacy information required.
 *
 * @package    local_adaptable
 * @copyright  2023 G J Barnard
 *               {@link https://moodle.org/user/profile.php?id=442195}
 *               {@link https://gjbarnard.co.uk}
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later.

 */
namespace local_adaptable\privacy;

use core_privacy\local\metadata\collection;

/**
 * Provider class.
 */
class provider implements
    // This plugin has data.
    \core_privacy\local\metadata\provider,
    // This plugin has some sitewide user preferences to export.
    \core_privacy\local\request\user_preference_provider {
    /** The user preferences for the userfavmenutitle. */
    const USER_FAV_MENU_TITLE = 'local_adaptable_user_userfavmenutitle';

    /** The user preferences for the userfavmenu. */
    const USER_FAV_MENU = 'local_adaptable_user_userfavmenu';

    /** The user preferences for the mysitessortoverride. */
    const MY_SITE_SORT_OVERRIDE = 'local_adaptable_user_mysitessortoverride';

    /**
     * Returns meta data about this system.
     *
     * @param  collection $items The initialised item collection to add items to.
     * @return collection A listing of user data stored through this system.
     */
    public static function get_metadata(collection $items): collection {
        $items->add_user_preference(self::USER_FAV_MENU_TITLE, 'privacy:metadata:preference:userfavmenutitle');
        $items->add_user_preference(self::USER_FAV_MENU, 'privacy:metadata:preference:userfavmenu');
        $items->add_user_preference(self::MY_SITE_SORT_OVERRIDE, 'privacy:metadata:preference:usermysitessortoverride');
        return $items;
    }

    /**
     * Store all user preferences for the plugin.
     *
     * @param int $userid The userid of the user whose data is to be exported.
     */
    public static function export_user_preferences(int $userid) {
        $mysitessortoverride = get_user_preferences(self::MY_SITE_SORT_OVERRIDE, null, $userid);
        if (isset($mysitessortoverride)) {
            $choices = \local_adaptable\output\my_courses::usermysitessortoverridechoices();

            \core_privacy\local\request\writer::export_user_preference(
                'local_adaptable',
                self::MY_SITE_SORT_OVERRIDE,
                $mysitessortoverride,
                get_string('privacy:usermysitessortoverrideexport', 'local_adaptable', [
                    'value' => $mysitessortoverride,
                    'description' => $choices[$mysitessortoverride],
                ])
            );
        }

        $userfavmenutitle = get_user_preferences(self::USER_FAV_MENU_TITLE, null, $userid);
        if (isset($userfavmenutitle)) {
            \core_privacy\local\request\writer::export_user_preference(
                'local_adaptable',
                self::USER_FAV_MENU_TITLE,
                $userfavmenutitle,
                get_string('privacy:userfavmenutitleexport', 'local_adaptable', [
                    'value' => $userfavmenutitle,
                ])
            );
        }

        $userfavmenu = get_user_preferences(self::USER_FAV_MENU, null, $userid);
        if (isset($userfavmenu)) {
            \core_privacy\local\request\writer::export_user_preference(
                'local_adaptable',
                self::USER_FAV_MENU,
                $userfavmenu,
                get_string('privacy:userfavmenuexport', 'local_adaptable', [
                    'value' => $userfavmenu,
                ])
            );
        }
    }
}

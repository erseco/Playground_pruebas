<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * News ticker.
 *
 * @package    local_adaptable
 * @copyright  2015-2019 Jeremy Hopkins (Coventry University)
 * @copyright  2015-2019 Fernando Acedo (3-bits.com)
 * @copyright  2017-2019 Manoj Solanki (Coventry University)
 * @copyright  2023 G J Barnard
 *               {@link https://moodle.org/user/profile.php?id=442195}
 *               {@link https://gjbarnard.co.uk}
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later.
 */

namespace local_adaptable\output;

use theme_adaptable\toolbox;

/**
 * Class definition.
 */
class login {
    /**
     * Generates elements of the login main content.
     *
     * @param string   $logincontent Login content.
     * @param stdClass $settings theme settings.
     *
     * return stdClass Header and Footer inclusion booleans.
     */
    public function generate_login(&$logincontent, $settings) {
        if ((!empty($settings->logintextboxtop)) || (!empty($settings->logintextboxbottom))) {
            $logintextstartwrapper1 = '<div class="row justify-content-center">';
            $logintextstartwrapper3 = '<div class="card"><div class="card-block">';
            $logintextendwrapper = '</div></div></div></div>';
            $logintextboxtop = '';
            $logintextboxbottom = '';
            if (!empty($settings->logintextboxtop)) {
                $logintextboxtop = $logintextstartwrapper1 . '<div class="col-xl-6 col-sm-8 mb-sm-5 mb-md-3 mb-lg-2">' .
                    $logintextstartwrapper3 . format_text($settings->logintextboxtop, FORMAT_MOODLE) . $logintextendwrapper;
            }
            if (!empty($settings->logintextboxbottom)) {
                $logintextboxbottom = $logintextstartwrapper1 . '<div class="col-xl-6 col-sm-8 mt-sm-5 mt-md-3 mt-lg-2">' .
                    $logintextstartwrapper3 . format_text($settings->logintextboxbottom, FORMAT_MOODLE) . $logintextendwrapper;
            }
            $logincontent = $logintextboxtop . $logincontent . $logintextboxbottom;
        }
        $retr = new \stdClass();
        $retr->header = $settings->loginheader;
        $retr->footer = $settings->loginfooter;

        return $retr;
    }

    /**
     * Generates the login styles.
     *
     * @param theme_config $theme The theme config object.
     *
     * return stdClass style strings.
     */
    public function login_style($theme) {
        $retr = new \stdClass();

        if (!empty($theme->settings->loginbgimage)) {
            $retr->loginbgimage = $theme->setting_file_url('loginbgimage', 'loginbgimage');
            $retr->loginbgimage = 'background-image: url("' . $retr->loginbgimage . '");';
        } else {
            $retr->loginbgimage = '';
        }

        if (!empty($theme->settings->loginbgstyle)) {
            $replacementstyle = 'cover';
            if ($theme->settings->loginbgstyle === 'stretch') {
                $replacementstyle = '100% 100%';
            }
            $retr->loginbgstyle = 'background-size: ' . $replacementstyle . ';';
        } else {
            $retr->loginbgstyle = '';
        }

        if (!empty($theme->settings->loginbgopacity)) {
            $retr->loginbgopacity = '#page-login-index header {' . PHP_EOL;
            $retr->loginbgopacity .= 'background-color: ' . toolbox::hex2rgba(
                $theme->settings->headermainrowbkcolour,
                $theme->settings->loginbgopacity
            ) . ' !important;' . PHP_EOL;
            $retr->loginbgopacity .= '}' . PHP_EOL;
            $retr->loginbgopacity .= '#page-login-index #page-navbar,' . PHP_EOL .
                '#page-login-index .login-container {';
            $retr->loginbgopacity .= 'background-color: rgba(255, 255, 255, ' . $theme->settings->loginbgopacity .
                ') !important;' . PHP_EOL;
            $retr->loginbgopacity .= '}' . PHP_EOL;
            $retr->loginbgopacity .= '#page-login-index #page-footer {' . PHP_EOL;
            $retr->loginbgopacity .= 'background-color: ' . toolbox::hex2rgba(
                $theme->settings->footerbkcolor,
                $theme->settings->loginbgopacity
            ) . ' !important;' . PHP_EOL;
            $retr->loginbgopacity .= '}' . PHP_EOL;
        } else {
            $retr->loginbgopacity = '';
        }

        return $retr;
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Alerts.
 *
 * @package    local_adaptable
 * @copyright  2015-2019 Jeremy Hopkins (Coventry University)
 * @copyright  2015-2019 Fernando Acedo (3-bits.com)
 * @copyright  2017-2019 Manoj Solanki (Coventry University)
 * @copyright  2023 G J Barnard
 *               {@link https://moodle.org/user/profile.php?id=442195}
 *               {@link https://gjbarnard.co.uk}
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later.
 */

namespace local_adaptable\output;

use core\output\html_writer;
use core\url;

/**
 * Class definition.
 */
class alerts {
    /**
     * @var $output Core renderer.
     */
    private $output = null;

    /**
     * @var @settings stdClass of settings.
     */
    private $settings = null;

    /**
     * Constructor.
     *
     * @param stdClass $page the page.
     */
    public function __construct($page) {
        $page->requires->js_call_amd('local_adaptable/alerts', 'init');
    }

    /**
     * Returns list of alert messages for the user.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     *
     * @return string Markup if any.
     */
    public function get_alert_messages($settings, $page, $output) {
        global $CFG;
        $alerts = '';

        $alertcount = $settings->alertcount;
        $this->settings = $settings;

        if (\core\session\manager::is_loggedinas()) {
            $alertindex = $alertcount + 1;
            $alertkey = "undismissable";
            $logininfo = $output->login_info();
            $logininfo = str_replace('<div class="logininfo">', '', $logininfo);
            $logininfo = str_replace('</div>', '', $logininfo);
            $alerts = $this->get_alert_message($logininfo, 'warning', $alertindex, $alertkey);
        }

        if (empty($settings->enablealerts)) {
            return $alerts;
        }

        $this->output = $output;

        for ($i = 1; $i <= $alertcount; $i++) {
            $enablealert = 'enablealert' . $i;
            $alerttext = 'alerttext' . $i;
            $alertsession = 'alert' . $i;

            if (isset($settings->$enablealert)) {
                $enablealert = $settings->$enablealert;
            } else {
                $enablealert = false;
            }

            if (isset($settings->$alerttext)) {
                $alerttext = $settings->$alerttext;
            } else {
                $alerttext = '';
            }

            if ($enablealert && !empty($alerttext)) {
                $alertprofilefield = 'alertprofilefield' . $i;
                $profilevals = ['', ''];

                if (!empty($settings->$alertprofilefield)) {
                    $profilevals = explode('=', $settings->$alertprofilefield);
                }

                $alertaccess = 'alertaccess' . $i;
                $alertaccess = $settings->$alertaccess;

                if ($this->get_alert_access($alertaccess, $profilevals[0], $profilevals[1], $alertsession)) {
                    $alerttype = 'alerttype' . $i;
                    $alerttype = $settings->$alerttype;
                    $alertkey = 'alertkey' . $i;
                    $alertkey = $settings->$alertkey;

                    if (!empty($settings->enablealertstriptags)) {
                        $alerttext = strip_tags($alerttext);
                    }
                    $enablealertstriptags = (!empty($settings->enablealertstriptags));

                    $alerts .= $this->get_alert_message($alerttext, $alerttype, $i, $alertkey, $enablealertstriptags);
                }
            }
        }

        if (is_role_switched($page->course->id)) {
            $alertindex = $alertcount + 1;
            $alertkey = "undismissable";

            $returnurl = $page->url->out_as_local_url(false);
            $url = $CFG->wwwroot . '/course/switchrole.php?id=' . $page->course->id . '&sesskey=' . sesskey() .
                '&switchrole=0&returnurl=' . $returnurl;

            $message = get_string('actingasrole', 'theme_adaptable') . '.  ';
            $message .= '<a href="' . $url . '">' . get_string('switchrolereturn') . '</a>';
            $alerts = $this->get_alert_message($message, 'warning', $alertindex, $alertkey) . $alerts;
        }

        return $alerts;
    }

    /**
     * Displays notices to alert teachers of problems with course such as being hidden.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     *
     * @return string Markup if any.
     */
    public function get_course_alerts($settings, $page, $output) {
        $retval = '';
        $alerttype = $settings->alerthiddencourse;
        if ($alerttype != 'disabled') {
            if ($page->course->visible == 0) {
                $this->output = $output;
                $this->settings = $settings;

                $alerttext =
                    get_string('alerthiddencoursetext-start', 'theme_adaptable') .
                    html_writer::link(new url(
                        '/course/edit.php',
                        ['id' => $page->course->id]
                    ), get_string('alerthiddencoursetext-link', 'theme_adaptable')) .
                    get_string('alerthiddencoursetext-end', 'theme_adaptable');

                $alertindexkey = 'hiddencoursealert-' . $page->course->id;
                // Don't use 'hiddencoursealert-' so that the same key can be used again.
                $alertkey = "undismissable";

                $retval = $this->get_alert_message($alerttext, $alerttype, $alertindexkey, $alertkey);
            }
        }

        return $retval;
    }

    /**
     * Returns formatted alert message
     *
     * @param string $text message text
     * @param string $type alert type
     * @param int $alertindex
     * @param int $alertkey
     * @param boolean $alertstriptags Strip tags from a dismissable alert.
     *
     * @return string
     */
    protected function get_alert_message($text, $type, $alertindex, $alertkey, $alertstriptags = false) {
        global $USER;
        if ($alertkey == '') {
            return '';
        }

        if ((!empty($USER->id)) && ($alertkey != 'undismissable')) {
            // Append hash of the content so that the key can be re-used when it changes.  Thus the key only needs to
            // change if you want to see the same content again.
            if ($alertstriptags) {
                $text = strip_tags($text);
                $alertkey = $alertkey . '_' . md5($text);
            } else {
                $alertkey = $alertkey . '_' . md5(strip_tags($text));
            }
            if ($this->get_alertkey($alertindex) == $alertkey) {
                return '';
            }
            $dismissable = 'dismissable';
        } else {
            $dismissable = 'undismissable';
        }

        $retval = '<div class="customalert alert alert-' . $dismissable . ' adaptable-alert-' . $type . ' fade in">';
        if ($dismissable != 'undismissable') {
            $retval .= '<button type="button" class="close" data-dismiss="alert" aria-label="Close" data-alertkey="' . $alertkey .
            '" data-alertindex="' . $alertindex . '">';
            $retval .= \theme_adaptable\toolbox::getfontawesomemarkup('times');
            $retval .= '</button>';
        }
        $retval .= $this->alert_icon($type);
        $retval .= $text;
        $retval .= '</div>';

        return $retval;
    }

    /**
     * Checks the users access to alerts
     * @param string $access the kind of access rule applied
     * @param string $profilefield the custom profile filed to check
     * @param string $profilevalue the expected value to be found in users profile
     * @param string $alertsession a token to be used to store access in session
     *
     * @return boolean
     */
    protected function get_alert_access($access, $profilefield, $profilevalue, $alertsession) {
        $retval = false;
        switch ($access) {
            case "global":
                $retval = true;
                break;
            case "user":
                if (isloggedin()) {
                    $retval = true;
                }
                break;
            case "admin":
                if (is_siteadmin()) {
                    $retval = true;
                }
                break;
            case "profile":
                /* Check if user is logged in and then check menu access for profile field. */
                if ((isloggedin()) && ($this->output->check_menu_access($profilefield, $profilevalue, $alertsession))) {
                    $retval = true;
                }
                break;
        }
        return $retval;
    }

    /**
     * Returns FA icon depending on the type of alert selected
     *
     * @param string $alertclassglobal
     *
     * @return string
     */
    protected function alert_icon($alertclassglobal) {
        switch ($alertclassglobal) {
            case "success":
                $alerticonglobal = $this->settings->alerticonsuccess;
                break;
            case "info":
                $alerticonglobal = $this->settings->alerticoninfo;
                break;
            case "warning":
                $alerticonglobal = $this->settings->alerticonwarning;
                break;
        }
        return \theme_adaptable\toolbox::getfontawesomemarkup($alerticonglobal);
    }

    /**
     * Get the key of the last closed alert for a specific alert index.
     * This will be used in the renderer to decide whether to include the alert or not
     * @param int $alertindex
     *
     * @return string Current value of the key.
     */
    protected function get_alertkey($alertindex) {
        global $USER;
        $USER->theme_adaptable_user_pref['theme_adaptable_alertkey' . $alertindex] = PARAM_TEXT;
        return get_user_preferences('theme_adaptable_alertkey' . $alertindex, '');
    }
}

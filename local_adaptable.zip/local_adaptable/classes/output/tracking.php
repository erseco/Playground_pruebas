<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Tracking.
 *
 * @package    local_adaptable
 * @copyright  2015-2019 Jeremy Hopkins (Coventry University)
 * @copyright  2015-2019 Fernando Acedo (3-bits.com)
 * @copyright  2017-2019 Manoj Solanki (Coventry University)
 * @copyright  2023 G J Barnard
 *               {@link https://moodle.org/user/profile.php?id=442195}
 *               {@link https://gjbarnard.co.uk}
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later.
 */

namespace local_adaptable\output;

/**
 * Class definition.
 */
class tracking {
    /**
     * Returns Google Analytics code if analytics are enabled
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $output the renderer.
     *
     * @return string Markup.
     */
    protected function get_analytics($settings, $output) {
        $analytics = '';

        if (!empty($settings->enableanalytics)) {
            $analyticscount = $settings->analyticscount;

            // Anonymize IP.
            if (!empty($settings->anonymizega)) {
                $anonymize = 'true';
            } else {
                $anonymize = 'false';
            }

            // Load settings.
            for ($i = 1; $i <= $analyticscount; $i++) {
                $analyticstext = 'analyticstext' . $i;
                $analyticsprofilefield = 'analyticsprofilefield' . $i;
                $analyticssession = 'analytics' . $i;
                $access = true;

                if (!empty($$analyticsprofilefield)) {
                    $profilevals = explode('=', $settings->$analyticsprofilefield);
                    $profilefield = $profilevals[0];
                    $profilevalue = $profilevals[1];
                    if (!$output->check_menu_access($profilefield, $profilevalue, $analyticssession)) {
                        $access = false;
                    }
                }

                if (!empty($settings->$analyticstext) && $access) {
                    // The closing tag of PHP heredoc doesn't like being indented so do not meddle with indentation of 'EOT;' below!
                    $analytics .= <<<EOT

                    <script type="text/javascript">
                        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
                        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
                        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

                        ga('create', '$analyticstext', 'auto');
                        ga('send', 'pageview');
                        ga('set', 'anonymizeIp', '$anonymize');
                    </script>
EOT;
                }
            }
        }
        return $analytics;
    }

    /**
     * Returns Piwik code if enabled.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     *
     * @copyright  2016 COMETE-UPO (Universit\E9 Paris Ouest)
     *
     * @return string Markup.
     */
    protected function get_piwik($settings, $page) {
        $analytics = '';
        $siteurl = $settings->piwiksiteurl;
        $siteid = $settings->piwiksiteid;

        if (
            $settings->piwikenabled &&
            !empty($siteurl) &&
            !empty($siteid) &&
            ($settings->piwiktrackadmin || !is_siteadmin())
        ) {
            // Cleanurl.
            $pageinfo = get_context_info_array($page->context->id);
            $trackurl = '';
            // Adds course category name.
            if (isset($pageinfo[1]->category)) {
                global $DB;
                if ($category = $DB->get_record('course_categories', ['id' => $pageinfo[1]->category])) {
                    $cats = explode("/", $category->path);
                    foreach (array_filter($cats) as $cat) {
                        if ($categorydepth = $DB->get_record("course_categories", ["id" => $cat])) {
                            $trackurl .= $categorydepth->name . '/';
                        }
                    }
                }
            }
            // Adds course full name.
            if (isset($pageinfo[1]->fullname)) {
                $trackurl .= $pageinfo[1]->fullname . '/';
                if (!isset($pageinfo[2]->name)) {
                    if ($page->user_is_editing()) {
                        $trackurl .= get_string('edit');
                    } else {
                        $trackurl .= get_string('view');
                    }
                }
            }
            // Adds module name.
            if (isset($pageinfo[2]->name)) {
                $trackurl .= get_string('pluginname', 'mod_' . $pageinfo[2]->modname) . '/' . $pageinfo[2]->name;
            }
            $trackurl = mb_ereg_replace('"', '\"', $trackurl);
            // Here we go.
            $analytics .= '<!-- Start Piwik Code -->' . PHP_EOL .
                '<script type="text/javascript">' .
                '   var _paq = _paq || [];' .
                '   _paq.push(["setDocumentTitle", "' . $trackurl . '"]);' .
                '   _paq.push(["trackPageView"]);' .
                '   _paq.push(["enableLinkTracking"]);' .
                '   (function() {' .
                '     var u="//' . $siteurl . '/";' .
                '     _paq.push(["setTrackerUrl", u+"piwik.php"]);' .
                '     _paq.push(["setSiteId", ' . $siteid . ']);' .
                '     var d=document, g=d.createElement("script"), s=d.getElementsByTagName("script")[0];' .
                '   g.type="text/javascript"; g.async=true; g.defer=true; g.src=u+"piwik.js";s.parentNode.insertBefore(g,s);' .
                '   })();' .
                '</script>' . PHP_EOL;
            if ($settings->piwikimagetrack) {
                $analytics .= '<noscript><p><img src="//' . $siteurl . '/piwik.php?idsite=' . $siteid .
                    '" style="border:0;"/></p></noscript>' . PHP_EOL;
            }
            $analytics .= '<!-- End Piwik Code -->';
        }
        return $analytics;
    }

    /**
     * Returns all tracking methods.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     *
     * @return string Markup.
     */
    public function get_all_tracking_methods($settings, $page, $output) {
        $analytics = $this->get_analytics($settings, $output);
        $analytics .= $this->get_piwik($settings, $page);
        return $analytics;
    }
}

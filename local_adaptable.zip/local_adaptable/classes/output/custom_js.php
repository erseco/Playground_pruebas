<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Custom JS.
 *
 * @package    local_adaptable
 * @copyright  2015-2019 Jeremy Hopkins (Coventry University)
 * @copyright  2015-2019 Fernando Acedo (3-bits.com)
 * @copyright  2017-2019 Manoj Solanki (Coventry University)
 * @copyright  2023 G J Barnard
 *               {@link https://moodle.org/user/profile.php?id=442195}
 *               {@link https://gjbarnard.co.uk}
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later.
 */

namespace local_adaptable\output;

/**
 * Class definition.
 */
class custom_js {
    /**
     * Returns custom JS if any.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     *
     * @return string Markup.
     */
    public function get_custom_js($settings, $page, $output) {
        $retval = '';

        if ((!empty($settings->customjs)) || (!empty($settings->jssectionrestrictedprofilefield))) {
            $context = new \stdClass();
            if (!empty($settings->customjs)) {
                $context->customjs = $settings->customjs;
            }

            // Conditional javascript based on a user profile field.
            if (!empty($settings->jssectionrestrictedprofilefield)) {
                global $CFG, $USER;
                // Get custom profile field setting. (e.g. faculty=fbl).
                $fields = explode('=', $settings->jssectionrestrictedprofilefield);
                $ftype = $fields[0];
                $setvalue = $fields[1];

                // Get user profile field (if it exists).
                require_once($CFG->dirroot . '/user/profile/lib.php');
                require_once($CFG->dirroot . '/user/lib.php');
                profile_load_data($USER);
                $ftype = "profile_field_$ftype";
                if (isset($USER->$ftype)) {
                    if ($USER->$ftype == $setvalue) {
                        // Match between user profile field value and value in setting.
                        if (!empty($settings->jssectionrestricteddashboardonly)) {
                            // If this is set to restrict to dashboard only, check if we are on dashboard page.
                            if ($page->pagelayout == 'mydashboard') {
                                $context->customjsrestricted = $settings->customjsrestricted;
                            }
                        } else {
                            $context->customjsrestricted = $settings->customjsrestricted;
                        }
                    }
                }
            }

            $output->render_from_template('local_adaptable/customjs', $context);
        }

        return $retval;
    }
}

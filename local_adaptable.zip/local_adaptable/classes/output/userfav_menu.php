<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * User favourites menu.
 *
 * @package    local_adaptable
 * @copyright  2024 G J Barnard
 *               {@link https://moodle.org/user/profile.php?id=442195}
 *               {@link https://gjbarnard.co.uk}
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later.
 */

namespace local_adaptable\output;

use context_course;
use theme_adaptable\output\custom_menu;
use stdClass;

/**
 * Class definition.
 */
class userfav_menu {
    /**
     * Returns html to render user favourites menu on the main navigation bar.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     *
     * @return string
     */
    public function userfavmenu($settings, $page, $output) {
        $retval = '';

        foreach ($this->userfavmenuitems($settings, $page, $output) as $custommenuitems) {
            $custommenu = new custom_menu($custommenuitems, current_language());
            $retval .= $output->render_custom_menu($custommenu);
        }

        return $retval;
    }

    /**
     * Returns array of custom menu items for the user favourites menu.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     *
     * @return array Of custom menu items.
     */
    public function userfavmenuitems($settings, $page, $output) {
        if ((empty($settings->enableuserfavmenu)) || (!isset($settings->enableuserfavmenu))) {
            return [];
        }

        $custommenuitems = '';
        $open = '';
        $retval = [];

        $navbardisplayicons = (!empty($settings->navbardisplayicons));
        $navbardisplaytitles = (!empty($settings->navbardisplaytitles));
        if (!$navbardisplaytitles && !$navbardisplayicons) {
            // Can't have nothing!
            $navbardisplaytitles = true;
        }

        $menu = get_user_preferences('local_adaptable_user_userfavmenu', '');

        if (!empty($menu) && !$output->hideinforum()) {
            $title = get_user_preferences('local_adaptable_user_userfavmenutitle', '');
            if (empty($title)) {
                $title = get_string('usersettings:fav', 'local_adaptable');
            }
            $label = '';
            if ($navbardisplaytitles) {
                $label .= '<span class="menutitle">' . $title . '</span>';
            }

            if ($navbardisplayicons) {
                $open = \theme_adaptable\toolbox::getfontawesomemarkup(
                    'userfavmenuicon',
                    [
                        'classes' => ['fa-lg'],
                        'settingicondefault' => 'star',
                    ]
                );
            }

            $retval[] = $output->parse_custom_menu($menu, $label, $title, $open);
        }

        return $retval;
    }

    /**
     * Render the user's favourites settings.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $output the renderer.
     *
     * @return string Markup.
     */
    public function render_user_fav_settings($settings, $output) {
        if ((empty($settings->enableuserfavmenu)) || (!isset($settings->enableuserfavmenu))) {
            return '';
        }
        $templatecontext = new stdClass();

        $templatecontext->title = get_user_preferences('local_adaptable_user_userfavmenutitle', '');
        $templatecontext->menu = get_user_preferences('local_adaptable_user_userfavmenu', '');

        return $output->render_from_template('local_adaptable/userfavourites', $templatecontext);
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Tools menu.
 *
 * @package    local_adaptable
 * @copyright  2015-2019 Jeremy Hopkins (Coventry University)
 * @copyright  2015-2019 Fernando Acedo (3-bits.com)
 * @copyright  2017-2019 Manoj Solanki (Coventry University)
 * @copyright  2023 G J Barnard
 *               {@link https://moodle.org/user/profile.php?id=442195}
 *               {@link https://gjbarnard.co.uk}
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later.
 */

namespace local_adaptable\output;

use context_course;
use theme_adaptable\output\custom_menu;

/**
 * Class definition.
 */
class tools_menu {
    /**
     * Returns html to render tools menu in main navigation bar.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     * @param string $menuid The id to use when creating menu.  Used so this could be called for a nav drawer style display.
     *
     * @return string Markup.
     */
    public function toolsmenu($settings, $page, $output, $menuid = '') {
        $retval = '';

        foreach ($this->toolsmenuitems($settings, $page, $output) as $custommenuitems) {
            $custommenu = new custom_menu($custommenuitems, current_language());
            $retval .= $output->render_custom_menu($custommenu, '', '', $menuid);
        }

        return $retval;
    }

    /**
     * Returns array of custom menu items for the tools menu(s).
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     *
     * @return array Of custom menu items.
     */
    public function toolsmenuitems($settings, $page, $output) {
        if ((empty($settings->enabletoolsmenus)) || (!isset($settings->toolsmenuscount))) {
            return [];
        }

        $custommenuitems = '';
        $access = true;
        $open = '';
        $retval = [];

        $navbardisplayicons = (!empty($settings->navbardisplayicons));
        $navbardisplaytitles = (!empty($settings->navbardisplaytitles));
        if (!$navbardisplaytitles && !$navbardisplayicons) {
            // Can't have nothing!
            $navbardisplaytitles = true;
        }

        $toolsmenuscount = $settings->toolsmenuscount;

        for ($i = 1; $i <= $toolsmenuscount; $i++) {
            $menunumber = 'toolsmenu' . $i;
            $menutitle = $menunumber . 'title';
            $accessrules = $menunumber . 'field';
            $access = true;

            if (!empty($settings->$accessrules)) {
                $fields = explode('=', $settings->$accessrules);
                $ftype = $fields[0];
                $setvalue = $fields[1];
                if (!$output->check_menu_access($ftype, $setvalue, $menunumber)) {
                    $access = false;
                }
            }

            if (!empty($settings->$menunumber) && $access == true && !$output->hideinforum()) {
                $menu = ($settings->$menunumber);
                $title = format_string($settings->$menutitle);
                $label = '';
                if ($navbardisplaytitles) {
                    $label .= '<span class="menutitle">' . $title . '</span>';
                }

                if ($navbardisplayicons) {
                    $menuicon = $menunumber . 'icon';
                    $open = \theme_adaptable\toolbox::getfontawesomemarkup(
                        $menuicon,
                        [
                            'classes' => ['fa-lg'],
                            'settingicondefault' => 'wrench',
                        ]
                    );
                }

                $retval[] = $output->parse_custom_menu($menu, $label, $title, $open);
            }
        }

        return $retval;
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * My Courses.
 *
 * @package    local_adaptable
 * @copyright  2015-2019 Jeremy Hopkins (Coventry University)
 * @copyright  2015-2019 Fernando Acedo (3-bits.com)
 * @copyright  2017-2019 Manoj Solanki (Coventry University)
 * @copyright  2023 G J Barnard
 *               {@link https://moodle.org/user/profile.php?id=442195}
 *               {@link https://gjbarnard.co.uk}
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later.
 */

namespace local_adaptable\output;

use context_course;
use core\url;
use theme_adaptable\toolbox;
use stdClass;

define('ADAPTABLE_COURSE_STARRED', 'starred');
define('ADAPTABLE_COURSE_IN_PROGRESS', 'inprogress');
define('ADAPTABLE_COURSE_PAST', 'past');
define('ADAPTABLE_COURSE_FUTURE', 'future');
define('ADAPTABLE_COURSE_HIDDEN', 'hidden');

/**
 * Class definition.
 */
class my_courses {
    /**
     * @var @settings stdClass of settings.
     */
    private $settings = null;

    /**
     * Creates the My Courses menu if enabled.
     *
     * @param custom_menu_item $menu The parent menu to add to.
     * @param int $branchsort Branch sort value to add to if the menu is added.
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     */
    public function get_mycourses(
        $menu,
        &$branchsort,
        $settings,
        $page,
        $output
    ) {
        if (!empty($settings->enablemysites)) {
            $mysitesvisibility = $settings->enablemysites;
        }
        if ($mysitesvisibility != 'disabled') {
            $showmysites = true;

            // Check custom profile field to restrict display of menu.
            if (!empty($settings->enablemysitesrestriction)) {
                $fields = explode('=', $settings->enablemysitesrestriction);
                $ftype = $fields[0];
                $setvalue = $fields[1];

                if (!$output->check_menu_access($ftype, $setvalue, 'mysitesrestriction')) {
                    $showmysites = false;
                }
            }

            if ($showmysites) {
                $this->settings = $settings;

                $overridetype = 'myoverview';
                $overridelist = null;

                $mysitessortoverride = '';
                if (!empty($settings->enableusermysitessortoverride)) {
                    $mysitessortoverride = get_user_preferences('local_adaptable_user_mysitessortoverride', 'theme');
                }
                if ((empty($mysitessortoverride)) || ($mysitessortoverride == 'theme')) {
                    if (!empty($this->settings->mysitessortoverride)) {
                        $overridetype = $this->settings->mysitessortoverride;
                    } else {
                        $overridetype = 'myoverview';
                    }
                } else {
                    $overridetype = $mysitessortoverride;
                }

                if (!empty($this->settings->mysitessortoverridefield)) {
                    $overridelist = $this->settings->mysitessortoverridefield;
                }

                if (($overridetype == 'profilefields' || $overridetype == 'profilefieldscohort') && (isset($overridelist))) {
                    $overridelist = $this->get_profile_field_contents($overridelist);

                    if ($overridetype == 'profilefieldscohort') {
                        $overridelist = array_merge($this->get_cohort_enrollments(), $overridelist);
                    }
                }

                if ($overridetype == 'strings' && isset($overridelist)) {
                    $overridelist = explode(',', $overridelist);
                }

                $navbardisplayicons = (!empty($this->settings->navbardisplayicons));
                $navbardisplaytitles = (!empty($this->settings->navbardisplaytitles));
                if (!$navbardisplaytitles && !$navbardisplayicons) {
                    // Can't have nothing!
                    $navbardisplaytitles = true;
                }

                $branchlabel = '';
                $branchtitle = get_string('mysites', 'theme_adaptable');
                if ($navbardisplayicons) {
                    $branchlabel .= toolbox::getfontawesomemarkup('briefcase', ['classes' => ['fa-lg']]);
                }
                if ($navbardisplaytitles) {
                    $branchlabel .= '<span class="menutitle">' . $branchtitle . '</span>';
                }
                $branchurl = new url('#');
                $menudisplayoption = '';

                // Check menu hover settings.
                if (isset($settings->mysitesmenudisplay)) {
                    $menudisplayoption = $settings->mysitesmenudisplay;
                } else {
                    $menudisplayoption = 'shortcodehover';
                }

                // The two variables below will control the 4 options available from the settings above for mysitesmenuhover.
                $showshortcode = true;  // If false, then display full course name.
                $showhover = true;

                switch ($menudisplayoption) {
                    case 'shortcodenohover':
                        $showhover = false;
                        break;
                    case 'fullnamenohover':
                        $showshortcode = false;
                        $showhover = false;
                        break;
                    case 'fullnamehover':
                        $showshortcode = false;
                        break;
                }

                // Calls a local method to get list of a user's current courses that they are enrolled on.
                $sortedcourses = $this->fetch_mycourses($overridetype);

                /* Add top level menu option here after finding out if there will be at least one course to display.  This is
                   for the option of displaying a sub-menu arrow symbol above, if configured in the theme settings. */
                $branchsort++;
                $branch = $menu->add($branchlabel, $branchurl, $branchtitle, $branchsort);
                $icon = '';

                if ($sortedcourses) {
                    $mysitesmaxlength = '30';
                    if (!empty($this->settings->mysitesmaxlength)) {
                        $mysitesmaxlength = $this->settings->mysitesmaxlength;
                    }

                    $mysitesmaxlengthhidden = $mysitesmaxlength - 3;

                    if ($overridetype == 'myoverview') {
                        $myoverviewcourses = $this->parsemyoverview($sortedcourses);

                        if (!empty($myoverviewcourses[ADAPTABLE_COURSE_STARRED])) {
                            $icon = toolbox::getfontawesomemarkup('star-o', ['classes' => ['afaicon']]);
                            $this->addcoursestomenu(
                                $branch,
                                $myoverviewcourses[ADAPTABLE_COURSE_STARRED],
                                $showshortcode,
                                $showhover,
                                $mysitesmaxlength,
                                $mysitesvisibility,
                                $icon
                            );
                        }

                        if (!empty($myoverviewcourses[ADAPTABLE_COURSE_IN_PROGRESS])) {
                            $icon = toolbox::getfontawesomemarkup('tasks', ['classes' => ['afaicon']]);
                            $child = $branch->add(
                                $icon . rtrim(mb_strimwidth(
                                    format_string(get_string('inprogress', 'theme_adaptable')),
                                    0,
                                    $mysitesmaxlengthhidden
                                )) . '...',
                                $page->url,
                                '',
                                1000
                            );
                            $this->addcoursestomenu(
                                $child,
                                $myoverviewcourses[ADAPTABLE_COURSE_IN_PROGRESS],
                                $showshortcode,
                                $showhover,
                                $mysitesmaxlength,
                                $mysitesvisibility
                            );
                        }

                        if (!empty($myoverviewcourses[ADAPTABLE_COURSE_PAST])) {
                            $icon = toolbox::getfontawesomemarkup('history', ['classes' => ['afaicon']]);
                            $child = $branch->add(
                                $icon . rtrim(mb_strimwidth(
                                    format_string(get_string('past', 'theme_adaptable')),
                                    0,
                                    $mysitesmaxlengthhidden
                                )) . '...',
                                $page->url,
                                '',
                                1000
                            );
                            $this->addcoursestomenu(
                                $child,
                                $myoverviewcourses[ADAPTABLE_COURSE_PAST],
                                $showshortcode,
                                $showhover,
                                $mysitesmaxlength,
                                $mysitesvisibility
                            );
                        }

                        if (!empty($myoverviewcourses[ADAPTABLE_COURSE_FUTURE])) {
                            $icon = toolbox::getfontawesomemarkup('clock-o', ['classes' => ['afaicon']]);
                            $child = $branch->add(
                                $icon . rtrim(mb_strimwidth(
                                    format_string(get_string('future', 'theme_adaptable')),
                                    0,
                                    $mysitesmaxlengthhidden
                                )) . '...',
                                $page->url,
                                '',
                                1000
                            );
                            $this->addcoursestomenu(
                                $child,
                                $myoverviewcourses[ADAPTABLE_COURSE_FUTURE],
                                $showshortcode,
                                $showhover,
                                $mysitesmaxlength,
                                $mysitesvisibility
                            );
                        }

                        if (!empty($myoverviewcourses[ADAPTABLE_COURSE_HIDDEN])) {
                            $faicon = (!empty($this->page->theme->settings->chiddenicon)) ?
                            $settings->chiddenicon : '';
                            $hiddenicon = toolbox::getfontawesomemarkup($faicon, ['classes' => ['afaicon']]);
                            $child = $branch->add(
                                $hiddenicon . rtrim(mb_strimwidth(
                                    format_string(get_string('hiddenfromview', 'theme_adaptable')),
                                    0,
                                    $mysitesmaxlengthhidden
                                )) . '...',
                                $page->url,
                                '',
                                1000
                            );
                            $this->addcoursestomenu(
                                $child,
                                $myoverviewcourses[ADAPTABLE_COURSE_HIDDEN],
                                $showshortcode,
                                $showhover,
                                $mysitesmaxlength,
                                $mysitesvisibility
                            );
                        }
                    } else {
                        foreach ($sortedcourses as $course) {
                            if ($course->visible) {
                                $coursename = '';
                                $rawcoursename = ''; // Untrimmed course name.

                                if ($showshortcode) {
                                    $coursename = mb_strimwidth(
                                        format_string($course->shortname),
                                        0,
                                        $mysitesmaxlength,
                                        '...',
                                        'utf-8'
                                    );
                                } else {
                                    $coursename = mb_strimwidth(
                                        format_string($course->fullname),
                                        0,
                                        $mysitesmaxlength,
                                        '...',
                                        'utf-8'
                                    );
                                }

                                if ($showhover) {
                                    $alttext = $course->fullname;
                                } else {
                                    $alttext = '';
                                }

                                if (!$overridelist) { // Feature not in use, add to menu as normal.
                                    $icon = $this->getcoursemenuicons($course);
                                    $branch->add(
                                        $icon . $coursename,
                                        new url('/course/view.php?id=' . $course->id),
                                        $alttext
                                    );
                                } else {
                                    // We want to check against array from profile field.
                                    if (
                                        (($overridetype == 'profilefields' ||
                                         $overridetype == 'profilefieldscohort') &&
                                         in_array($course->shortname, $overridelist)) ||
                                        ($overridetype == 'strings' &&
                                            $this->check_if_in_array_string($overridelist, $course->shortname))
                                    ) {
                                        $icon = $this->getcoursemenuicons($course);
                                        $branch->add(
                                            $icon . $coursename,
                                            new url('/course/view.php?id=' . $course->id),
                                            $alttext,
                                            100
                                        );
                                    } else {
                                        // If not in array add to sub menu item.
                                        if (!isset($child)) {
                                            $icon = toolbox::getfontawesomemarkup('history', ['classes' => ['afaicon']]);
                                            $child = $branch->add(
                                                $icon . rtrim(
                                                    mb_strimwidth(
                                                        format_string(get_string('pastcourses', 'theme_adaptable')),
                                                        0,
                                                        $mysitesmaxlengthhidden
                                                    )
                                                ) . '...',
                                                $page->url,
                                                $alttext,
                                                1000
                                            );
                                        }

                                        $rawcoursename = ($showshortcode) ? $course->shortname : $course->fullname;

                                        $icon = $this->getcoursemenuicons($course);
                                        $child->add(
                                            $icon . rtrim(mb_strimwidth(
                                                format_string($rawcoursename),
                                                0,
                                                $mysitesmaxlengthhidden
                                            )) . '...',
                                            new url('/course/view.php?id=' . $course->id),
                                            format_string($rawcoursename)
                                        );
                                    }
                                }
                            }
                        }

                        $faicon = (!empty($settings->chiddenicon)) ? $settings->chiddenicon : 'eye-slash';
                        $hiddenicon = toolbox::getfontawesomemarkup($faicon, ['classes' => ['afaicon']]);
                        $child = null;
                        foreach ($sortedcourses as $course) {
                            $coursecontext = context_course::instance($course->id);
                            if (
                                !$course->visible && $mysitesvisibility == 'includehidden' &&
                                has_capability('moodle/course:viewhiddencourses', $coursecontext)
                            ) {
                                if (empty($child)) {
                                    $child = $branch->add(
                                        $hiddenicon .
                                        rtrim(mb_strimwidth(
                                            format_string(get_string('hiddencourses', 'theme_adaptable')),
                                            0,
                                            $mysitesmaxlengthhidden
                                        )) . '...',
                                        $page->url,
                                        '',
                                        2000
                                    );
                                }

                                $icon = $this->getcoursemenuicons($course, $hiddenicon);
                                $child->add(
                                    $icon . rtrim(mb_strimwidth(
                                        format_string($course->fullname),
                                        0,
                                        $mysitesmaxlengthhidden
                                    )) . '...',
                                    new url('/course/view.php?id=' . $course->id),
                                    format_string($course->shortname)
                                );
                            }
                        }
                    }
                } else {
                    $noenrolments = get_string('noenrolments', 'theme_adaptable');
                    $branch->add(
                        '<em>' . $noenrolments . '</em>',
                        new url('/'),
                        $noenrolments
                    );
                }
            }
        }
    }

    /**
     * Render the user's 'mysitessortoverride' select.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $output the renderer.
     *
     * @return string Markup.
     */
    public function render_user_mysitessortoverride_select($settings, $output) {
        if ((empty($settings->enableusermysitessortoverride)) || (!isset($settings->enableusermysitessortoverride))) {
            return '';
        }

        $templatecontext = new stdClass();

        $currentmysitessortoverride = get_user_preferences('local_adaptable_user_mysitessortoverride', 'theme');
        if (empty($currentmysitessortoverride)) {
            $currentmysitessortoverride = 'theme';
        }

        $templatecontext->options = [];

        foreach (self::usermysitessortoverridechoices() as $key => $value) {
            $option = new stdClass();
            $option->option = $value;
            $option->value = $key;
            if ($key == $currentmysitessortoverride) {
                $option->selected = true;
            }
            $templatecontext->options[] = $option;
        }

        return $output->render_from_template('local_adaptable/usermysitessortoverride', $templatecontext);
    }

    /**
     * Return the array .
     *
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     *
     * @return array Choices.
     */
    public static function usermysitessortoverridechoices() {
        $choices = [
            'theme' => get_string('usersettings:mysitessortoverridetheme', 'local_adaptable'),
            'off' => get_string('mysitessortoverrideoff', 'theme_adaptable'),
            'strings' => get_string('mysitessortoverridestrings', 'theme_adaptable'),
            'profilefields' => get_string('mysitessortoverrideprofilefields', 'theme_adaptable'),
            'profilefieldscohort' => get_string('mysitessortoverrideprofilefieldscohort', 'theme_adaptable'),
            'myoverview' => get_string('mysitessortoverridemyoverview', 'theme_adaptable'),
            'last' => get_string('mysitessortoverridelast', 'theme_adaptable'),
        ];
        return $choices;
    }

    /**
     * Return list of the user's courses
     *
     * @param string $overridetype The override type.
     *
     * @return array list of courses
     */
    protected function fetch_mycourses($overridetype) {
        // Set limit of courses to show in dropdown from setting.
        $coursedisplaylimit = '20';
        if (isset($this->settings->mycoursesmenulimit)) {
            $coursedisplaylimit = $this->settings->mycoursesmenulimit;
        }

        $courses = enrol_get_my_courses(
            join(',', array_keys(\core_course\external\course_summary_exporter::define_properties()))
        );

        /* Add timeaccess and timestart to the courses for all override types to use in some shape or form.
           Get the last accessed information for the user and populate. */
        global $DB, $USER;
        $lastaccess = $DB->get_records('user_lastaccess', ['userid' => $USER->id], '', 'courseid, timeaccess');
        if ($lastaccess) {
            foreach ($courses as $course) {
                if (!empty($lastaccess[$course->id])) {
                    $course->timeaccess = $lastaccess[$course->id]->timeaccess;
                }
            }
        }
        // Determine if we need to query the enrolment and user enrolment tables.
        $enrolquery = false;
        foreach ($courses as $course) {
            if (empty($course->timeaccess)) {
                $enrolquery = true;
                break;
            }
        }
        if ($enrolquery) {
            // We do.
            $params = ['userid' => $USER->id];
            $sql = "SELECT ue.id, e.courseid, ue.timestart
                FROM {enrol} e
                JOIN {user_enrolments} ue ON (ue.enrolid = e.id AND ue.userid = :userid)";
            $enrolments = $DB->get_records_sql($sql, $params, 0, 0);
            if ($enrolments) {
                // Sort out any multiple enrolments on the same course.
                $userenrolments = [];
                foreach ($enrolments as $enrolment) {
                    if (!empty($userenrolments[$enrolment->courseid])) {
                        if ($userenrolments[$enrolment->courseid] < $enrolment->timestart) {
                            // Replace.
                            $userenrolments[$enrolment->courseid] = $enrolment->timestart;
                        }
                    } else {
                        $userenrolments[$enrolment->courseid] = $enrolment->timestart;
                    }
                }
                // We don't need to worry about timeend etc. as our course list will be valid for the user from above.
                foreach ($courses as $course) {
                    if (empty($course->timeaccess)) {
                        $course->timestart = $userenrolments[$course->id];
                    }
                }
            }
        }

        if ($overridetype == 'last') {
            uasort($courses, [$this, 'timeaccesscompare']);
        }

        // Get courses in sort order into list.
        if ($coursedisplaylimit != 0) {
            $sortedcourses = [];
            $counter = 0;
            foreach ($courses as $course) {
                if ($counter >= $coursedisplaylimit) {
                    break;
                }
                $sortedcourses[] = $course;
                $counter++;
            }
        } else {
            $sortedcourses = $courses;
        }

        return $sortedcourses;
    }

    /**
     * Compares two course entries against their access time for a user to see which is first.
     *
     * @param stdClass $a A course.
     * @param stdClass $b A course.
     *
     * @return int -1 'a' is first, 1 'b' is first or 0 they are equal.
     */
    protected static function timeaccesscompare($a, $b) {
        // The timeaccess is lastaccess entry and timestart an enrol entry.
        if ((!empty($a->timeaccess)) && (!empty($b->timeaccess))) {
            // Both last access.
            if ($a->timeaccess == $b->timeaccess) {
                return 0;
            }
            return ($a->timeaccess > $b->timeaccess) ? -1 : 1;
        } else if ((!empty($a->timestart)) && (!empty($b->timestart))) {
            // Both enrol.
            if ($a->timestart == $b->timestart) {
                return 0;
            }
            return ($a->timestart > $b->timestart) ? -1 : 1;
        }

        /* Must be comparing an enrol with a last access.
           -1 is to say that 'a' comes before 'b'. */
        if (!empty($a->timestart)) {
            // If 'a' is the enrol entry.
            return -1;
        }
        // Then 'b' must be the enrol entry.
        return 1;
    }

    /**
     * Returns contents of multiple comma delimited custom profile fields.
     *
     * @param string $profilefields delimited list of fields.
     * @return array of multiple comma delimited custom profile fields.
     */
    protected function get_profile_field_contents($profilefields) {
        global $CFG, $USER;
        $timestamp = 'currentcoursestime';
        $list = 'currentcourseslist';
        $time = time();

        if (isset($USER->theme_adaptable_menus[$timestamp])) {
            if ($USER->theme_adaptable_menus[$timestamp] >= $time) {
                if (isset($USER->theme_adaptable_menus[$list])) {
                    return $USER->theme_adaptable_menus[$list];
                }
            }
        }

        $retval = [];

        require_once($CFG->dirroot . '/user/profile/lib.php');
        require_once($CFG->dirroot . '/user/lib.php');
        profile_load_data($USER);

        $fields = explode(',', $profilefields);
        foreach ($fields as $field) {
            $field = trim($field);
            $field = "profile_field_$field";
            if (isset($USER->$field)) {
                $vals = explode(',', $USER->$field);
                foreach ($vals as $value) {
                    $retval[] = trim($value);
                }
            }
        }

        $USER->theme_adaptable_menus[$list] = $retval;
        $USER->theme_adaptable_menus[$timestamp] = $time + 1000 * 60 * 3; // Sess TTL.

        return $retval;
    }

    /**
     * Returns list of cohort enrollments
     *
     * @return array
     */
    protected function get_cohort_enrollments() {
        global $DB, $USER;
        $userscohorts = $DB->get_records('cohort_members', ['userid' => $USER->id]);
        $courses = [];
        if ($userscohorts) {
            $cohortedcourseslist = $DB->get_records_sql('select '
                    . 'courseid '
                    . 'from {enrol} '
                    . 'where enrol = "cohort" '
                    . 'and customint1 in (?)', array_keys($userscohorts));
            $cohortedcourses = $DB->get_records_list('course', 'id', array_keys($cohortedcourseslist), null, 'shortname');
            foreach ($cohortedcourses as $course) {
                $courses[] = $course->shortname;
            }
        }
        return($courses);
    }

    /**
     * Get the icon markup of the icon(s) for the course that will be used in its menu item.
     *
     * @param stdClass $course Course.
     * @param string $existingicon Existing icon markup if any.
     *
     * @return string Icon markup(s).
     */
    protected function getcoursemenuicons($course, $existingicon = '') {
        global $CFG;
        $icon = $existingicon;

        if (!empty($course->timestart)) {
            $faicon = (!empty($this->settings->cneveraccessedicon)) ?
                $this->settings->cneveraccessedicon : '';
            $icon .= toolbox::getfontawesomemarkup($faicon);
        }

        if (!empty($CFG->contextlocking)) {
            $context = context_course::instance($course->id);
            if ($context->locked) {
                $faicon = (!empty($this->settings->cfrozenicon)) ?
                    $this->settings->cfrozenicon : '';
                $icon .= toolbox::getfontawesomemarkup($faicon);
            }
        }

        if (empty($icon)) {
            $faicon = (!empty($this->settings->cdefaulticon)) ?
                $this->settings->cdefaulticon : '';
            $icon = toolbox::getfontawesomemarkup($faicon);
        }

        return $icon;
    }

    /**
     * Classify the courses in the same way that the My Overview block does non the dashboard.
     *
     * @param array $sortedcourses Array of courses - must contain the fields by 'define_properties' in 'course_summary_exporter'.
     *
     * @return array array of arrays that classify the courses.
     */
    protected function parsemyoverview(&$sortedcourses) {
        global $USER;

        $ufservice = \core_favourites\service_factory::get_service_for_user_context(\context_user::instance($USER->id));
        $starred = $ufservice->find_favourites_by_type('core_course', 'courses');
        $starredids = [];

        if ($starred) {
            $starredids = array_map(
                function ($favourite) {
                    return $favourite->itemid;
                },
                $starred
            );
        }

        $hiddenids = get_hidden_courses_on_timeline($USER);

        $myoverviewcourses = [
            ADAPTABLE_COURSE_STARRED => [],
            ADAPTABLE_COURSE_IN_PROGRESS => [],
            ADAPTABLE_COURSE_PAST => [],
            ADAPTABLE_COURSE_FUTURE => [],
            ADAPTABLE_COURSE_HIDDEN => [],
        ];

        foreach ($sortedcourses as $course) {
            if (in_array($course->id, $starredids)) {
                $myoverviewcourses[ADAPTABLE_COURSE_STARRED][] = $course;
            } // Starred can also appear in the respective sub-menu.
            if (in_array($course->id, $hiddenids)) {
                $myoverviewcourses[ADAPTABLE_COURSE_HIDDEN][] = $course;
            } else {
                switch (course_classify_for_timeline($course, $USER)) {
                    case COURSE_TIMELINE_PAST:
                        $myoverviewcourses[ADAPTABLE_COURSE_PAST][] = $course;
                        break;
                    case COURSE_TIMELINE_FUTURE:
                        $myoverviewcourses[ADAPTABLE_COURSE_FUTURE][] = $course;
                        break;
                    case COURSE_TIMELINE_INPROGRESS:
                        $myoverviewcourses[ADAPTABLE_COURSE_IN_PROGRESS][] = $course;
                        break;
                }
            }
        }

        return $myoverviewcourses;
    }

    /**
     * Adds the given array of courses to the supplied menu.
     *
     * @param custom_menu_item $menu The menu to add to.
     * @param array $courses Array of courses.
     * @param bool $showshortcode Use the course shortname instead of full.
     * @param bool $showhover Put the course full name in the alternative text.
     * @param int $mysitesmaxlength Max length of the course name string displayed.
     * @param bool $mysitesvisibility Value of the 'enablemysites' setting.
     * @param string $icon Prefix an icon (HTML markup) if any.
     */
    protected function addcoursestomenu(
        &$menu,
        $courses,
        $showshortcode,
        $showhover,
        $mysitesmaxlength,
        $mysitesvisibility,
        $icon = ''
    ) {
        foreach ($courses as $course) {
            $coursecontext = context_course::instance($course->id);
            if (
                ($course->visible) ||
                (!$course->visible && $mysitesvisibility == 'includehidden' &&
                has_capability('moodle/course:viewhiddencourses', $coursecontext))
            ) {
                if ($showshortcode) {
                    $coursename = mb_strimwidth(
                        format_string($course->shortname),
                        0,
                        $mysitesmaxlength,
                        '...',
                        'utf-8'
                    );
                } else {
                    $coursename = mb_strimwidth(
                        format_string($course->fullname),
                        0,
                        $mysitesmaxlength,
                        '...',
                        'utf-8'
                    );
                }

                if ($showhover) {
                    $alttext = $course->fullname;
                } else {
                    $alttext = '';
                }

                $courseicon = $this->getcoursemenuicons($course, $icon);
                $menu->add($courseicon . $coursename, new url('/course/view.php?id=' . $course->id), $alttext);
            }
        }
    }

    /**
     * Returns true if needs from array found in haystack
     * @param array $needles a list of strings to check
     * @param string $haystack value which may contain string
     * @return boolean
     */
    public function check_if_in_array_string($needles, $haystack) {
        foreach ($needles as $needle) {
            $needle = trim($needle);
            if (strstr($haystack, $needle)) {
                return true;
            }
        }
        return false;
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Category headers.
 *
 * @package    local_adaptable
 * @copyright  2015-2019 Jeremy Hopkins (Coventry University)
 * @copyright  2015-2019 Fernando Acedo (3-bits.com)
 * @copyright  2017-2019 Manoj Solanki (Coventry University)
 * @copyright  2023 G J Barnard
 *               {@link https://moodle.org/user/profile.php?id=442195}
 *               {@link https://gjbarnard.co.uk}
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later.
 */

namespace local_adaptable\output;

/**
 * Class definition.
 */
class category_headers {
    /**
     * Returns the category header data required for header.php.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     *
     * @return array Current top level category and header backgound, if any.
     */
    public function get_header($settings, $page) {
        $retr = ['currenttopcat' => false, 'headerbg' => ''];
        if (!empty($settings->categoryhavecustomheader)) {
            $retr['currenttopcat'] = self::get_current_top_level_catetgory($page);
            if (!empty($retr['currenttopcat'])) {
                $categoryheaderbgimageset = 'categoryheaderbgimage' . $retr['currenttopcat'];
                if (!empty($settings->$categoryheaderbgimageset)) {
                    $retr['headerbg'] = ' class="headerbgimage categorybgimage" style="background-image: ' .
                    'url(\'' . $page->theme->setting_file_url($categoryheaderbgimageset, $categoryheaderbgimageset) . '\');"';
                }
            }
        }
        return $retr;
    }

    /**
     * Sets the logo.
     *
     * @param bool/int $currenttopcat The id of the current top category or false if none.
     * @param stdClass $settings theme settings.
     *
     * @return string $logosetarea the logo setting area.
     */
    public function get_logo($currenttopcat, &$logosetarea, $settings) {
        $logosetarea = '';
        if (!empty($currenttopcat)) {
            $categoryheaderlogoset = 'categoryheaderlogo' . $currenttopcat;
            if (!empty($settings->$categoryheaderlogoset)) {
                $logosetarea = $categoryheaderlogoset;
            }
        }
        return $logosetarea;
    }

    /**
     * Sets the custom title.
     *
     * @param bool/int $currenttopcat The id of the current top category or false if none.
     * @param stdClass $settings theme settings.
     *
     * @return string $categoryheadercustomtitle the custom title.
     */
    public function get_title($currenttopcat, &$categoryheadercustomtitle, $settings) {
        $categoryheadercustomtitle = '';
        if (!empty($currenttopcat)) {
            $categoryheadercustomtitleset = 'categoryheadercustomtitle' . $currenttopcat;
            if (!empty($settings->$categoryheadercustomtitleset)) {
                $categoryheadercustomtitle = $settings->$categoryheadercustomtitleset;
            }
        }
        return $categoryheadercustomtitle;
    }

    /**
     * Adds any category custom SCSS to the SCSS before it is cached.
     *
     * @param string $scss The original SCSS.
     * @param array $settings Theme settings.
     * @return string The SCSS which now contains our custom SCSS.
     */
    public function set_categorycustomcss($scss, $settings) {
        $tohavecustomheader = $settings->categoryhavecustomheader;
        $replacement = '';
        if (!empty($tohavecustomheader)) {
            $customheaderids = explode(',', $tohavecustomheader);
            $topcats = \theme_adaptable\toolbox::get_top_categories_with_children();
            $corescss = new \core_scss();
            $categoryscss = '';
            foreach ($customheaderids as $customheaderid) {
                $catids = [$customheaderid];
                $catinfo = $topcats[$customheaderid];
                if (!empty($catinfo['children'])) {
                    // Child categories.
                    $catids = array_merge($catids, array_keys($catinfo['children']));
                }
                $categoryids = [];
                foreach ($catids as $catid) {
                    $categoryids[] = '.category-' . $catid;
                }
                $categoryselector = implode(', ', $categoryids);

                // Text.
                $categoryheaderbgimagetextcolour = 'categoryheaderbgimagetextcolour' . $customheaderid;
                if (!empty($settings->$categoryheaderbgimagetextcolour)) {
                    $categoryscss .= $categoryselector . '{' . PHP_EOL;
                    $categoryscss .= '.categorybgimage #sitetitle, .categorybgimage .headersearch .btn {' . PHP_EOL;
                    $categoryscss .= 'color: ' . $settings->$categoryheaderbgimagetextcolour . ';' . PHP_EOL;
                    $categoryscss .= '}' . PHP_EOL;
                    $categoryscss .= '.categorybgimage #sitetitle {' . PHP_EOL;
                    $categoryscss .= 'a, p, h1, h2, h3, h4, h5, h6 {' . PHP_EOL;
                    $categoryscss .= 'color: ' . $settings->$categoryheaderbgimagetextcolour . ';' . PHP_EOL;
                    $categoryscss .= '}' . PHP_EOL;
                    $categoryscss .= '}' . PHP_EOL;
                    $categoryscss .= '}' . PHP_EOL;
                }

                // Custom CSS.
                $categoryheadercustomcssset = 'categoryheadercustomcss' . $customheaderid;
                if (!empty($settings->$categoryheadercustomcssset)) {
                    // Validate and add if ok.
                    try {
                        $categorycss = $corescss->compile($settings->$categoryheadercustomcssset);

                        $categoryscss .= $categoryselector . '{' . PHP_EOL;
                        $categoryscss .= $categorycss;
                        $categoryscss .= PHP_EOL . '}' . PHP_EOL;
                    } catch (Leafo\ScssPhp\Exception\ParserException $e) {
                        debugging(get_string(
                            'invalidcategoryscss',
                            'theme_adaptable',
                            ['scss' => $settings->$categoryheadercustomcssset,
                            'topcatname' => $catinfo['name'], 'topcatid' => $customheaderid, ]
                        ), DEBUG_NONE);
                    } catch (Leafo\ScssPhp\Exception\CompilerException $e) {
                        debugging(get_string(
                            'invalidcategoryscss',
                            'theme_adaptable',
                            ['scss' => $settings->$categoryheadercustomcssset,
                            'topcatname' => $catinfo['name'], 'topcatid' => $customheaderid, ]
                        ), DEBUG_NONE);
                    }
                }
            }

            if (!empty($categoryscss)) {
                try {
                    $replacement = $corescss->compile($categoryscss);
                } catch (\Leafo\ScssPhp\Exception\ParserException $e) {
                    debugging(get_string('invalidcategorygeneratedcss', 'theme_adaptable', ['css' => $categoryscss]), DEBUG_NONE);
                } catch (\Leafo\ScssPhp\Exception\CompilerException $e) {
                    debugging(get_string('invalidcategorygeneratedcss', 'theme_adaptable', ['css' => $categoryscss]), DEBUG_NONE);
                }
            }
        }

        $tag = '[[setting:catgorycustomcss]]';

        return str_replace($tag, $replacement, $scss);
    }

    /**
     * Get the current top level category.
     *
     * @return int category id.
     */
    private static function get_current_top_level_catetgory($page) {
        $catid = false;

        if (is_array($page->categories)) {
            $catids = array_keys($page->categories);
            if (!empty($catids)) {
                // The last entry in the array is the top level category.
                $catid = $catids[(count($catids) - 1)];
            }
        } else if (!empty($page->course->category)) {
            $catid = $page->course->category;
            // See if the course category is a top level one.
            if (!array_key_exists($catid, \theme_adaptable\toolbox::get_top_level_categories())) {
                $catid = false;
            }
        }

        return $catid;
    }
}

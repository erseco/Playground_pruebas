<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * News ticker.
 *
 * @package    local_adaptable
 * @copyright  2015-2019 Jeremy Hopkins (Coventry University)
 * @copyright  2015-2019 Fernando Acedo (3-bits.com)
 * @copyright  2017-2019 Manoj Solanki (Coventry University)
 * @copyright  2023 G J Barnard
 *               {@link https://moodle.org/user/profile.php?id=442195}
 *               {@link https://gjbarnard.co.uk}
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later.
 */

namespace local_adaptable\output;

/**
 * Class definition.
 */
class news_ticker {
    /**
     * Returns html to render news ticker.
     *
     * @param stdClass $settings theme settings.
     * @param stdClass $page the page.
     * @param stdClass $output the renderer.
     *
     * @return string
     */
    public function get_news_ticker($settings, $page, $output) {
        $retval = '';

        // Display ticker if possible.
        if (
            (!empty($settings->enableticker) &&
            $settings->enableticker &&
            $page->bodyid == "page-site-index") ||
            ($settings->enabletickermy && $page->bodyid == "page-my-index")
        ) {
            $msg = '';
            $tickercount = $settings->newstickercount;

            for ($i = 1; $i <= $tickercount; $i++) {
                $textfield = 'tickertext' . $i;
                $profilefield = 'tickertext' . $i . 'profilefield';

                $access = true;
                if (!empty($settings->$profilefield)) {
                    $profilevals = explode('=', $settings->$profilefield);
                    if (!$output->check_menu_access($profilevals[0], $profilevals[1], $textfield)) {
                        $access = false;
                    }
                }

                if (($access) && (!empty($settings->$textfield))) {
                    $msg .= format_text($settings->$textfield, FORMAT_HTML, ['trusted' => true]);
                }
            }

            $msg = preg_replace('#\<[\/]{0,1}(li|ul|div|pre|blockquote)\>#', '', $msg);
            if ($msg == '') {
                $msg = '<p>' . get_string('tickerdefault', 'theme_adaptable') . '</p>';
            }

            $newscontext = [
                'responsiveticker' => $settings->responsiveticker,
                'msg' => $msg,
            ];
            $retval = $output->render_from_template('local_adaptable/news_ticker', $newscontext);
        }

        return $retval;
    }
}

<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * myprofile category to add an extra attribute 'notitle'.
 *
 * @package    local_adaptable
 * @copyright  2025 G J Barnard
 *               {@link https://moodle.org/user/profile.php?id=442195}
 *               {@link https://gjbarnard.co.uk}
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later.
 */

namespace local_adaptable\output\core_user\myprofile;

use core_user\output\myprofile\category as category_parent;

/**
 * Class user category.
 */
class category extends category_parent {
    /** @var bool $notitle Show the title state. */
    public $notitle;

    /**
     * Constructor for category class.
     *
     * @param string $name Category name.
     * @param string $title category title.
     * @param null|string $after Name of category after which this category should appear.
     * @param null|string $classes a list of css classes.
     */
    public function __construct($name, $title, $after = null, $classes = null) {
        parent::__construct($name, $title, $after, $classes);
        $this->notitle = false;
    }
}

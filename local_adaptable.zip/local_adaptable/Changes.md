Change log in version 405.2.2 (2024100515)
==========================================
1. Specific version for Adaptable 405.2.2.

Change log in version 405.2.1 (2024100514)
==========================================
1. Specific version for Adaptable 405.2.1.
2. Fix missing tabbed user profile strings.
3. Fix 'Creation of dynamic property $notitle' for the user profile.

Change log in version 405.2.0 (2024100512)
==========================================
1. Specific version for Adaptable 405.2.0.
2. Changed setting 'headerbkcolor2' to 'headermainrowbkcolour'.
3. Support add of tools menu to 'mobileprimarynav' drawer.
4. Support add of user favourites menu to 'mobileprimarynav' drawer.
5. Add tools menu icon setting for each tools menu.
6. Add user favourites menu icon setting for the user favourites menu.
7. Changed 'mr-1' to 'afaicon' and apply margin in CSS.

Change log in version 405.1.10 (2024100511)
===========================================
1. Specific version for Adaptable 405.1.10.

Change log in version 405.1.9 (2024100510)
==========================================
1. Specific version for Adaptable 405.1.9.

Change log in version 405.1.8 (2024100509)
==========================================
1. Specific version for Adaptable 405.1.8.

Change log in version 405.1.7 (2024100508)
==========================================
1. Specific version for Adaptable 405.1.7.

Change log in version 405.1.6 (2024100507)
==========================================
1. Specific version for Adaptable 405.1.6.

Change log in version 405.1.5 (2024100506)
==========================================
1. Specific version for Adaptable 405.1.5.

Change log in version 405.1.4 (2024100505)
==========================================
1. Specific version for Adaptable 405.1.4.

Change log in version 405.1.3 (2024100504)
==========================================
1. Specific version for Adaptable 405.1.3.

Change log in version 405.1.2 (2024100503)
==========================================
1. Specific version for Adaptable 405.1.2.

Change log in version 405.1.1 (2024100502)
==========================================
1. Specific version for Adaptable 405.1.1.
2. Add theme user settings, initially 'My courses custom sort'.
3. Added tools menu title multilang support.
4. Added favourites menu user setting.
5. Add 'navbardisplaytitles' setting to show / hide the navbar titles, disabled when 'navbardisplayicons' is unset.

Change log in version 405.1.0 (2024100501)
==========================================
1. Specific version for Adaptable 405.1.0.

Change log in version 405.0.1 (2024100500)
==========================================
1. Specific version for Adaptable 405.0.1.
2. Impact of MDL-81920 and MDL-81960.

Change log in version 404.1.1 (2024051203)
==========================================
1. Specific version for Adaptable 404.1.1.
2. Moved ticker JS from theme.
3. Ticker style back to what it was.

Change log in version 404.1.0 (2024051202)
==========================================
1. Specific version for Adaptable 404.1.0.

Change log in version 404.0.2 (2024051201)
==========================================
1. Fix tools menu title in tag when 'navbardisplaysubmenuarrow' is set.

Change log in version 404.0.1 (2024051200)
==========================================
1. M4.4 sepecific version.  This facilitates progress / development in the lead 'main' branch before past branches
   are updated.

Change log in version 403.0.1 (2024032500)
==========================================
1. Add custom user preference code as user_preference_allow_ajax_update() is deprecated.
2. Because of '1' this version only supports M4.3+.  For the Moodle 4.1 / 4.2 version,
   please use: https://github.com/gjbarnard/moodle-local_adaptable/tree/MOODLE_401_2.
3. Unix file endings - use 'find . -type f -print0 | xargs -0 dos2unix' in a Git Bash on Windows if you need to.

Change log in version 401.0.4 (2023102203)
==========================================
1. Add supported methods and custom js.

Change log in version 401.0.3 (2023102202)
==========================================
1. Fix 'logged in as' alert FontAwesome icon.

Change log in version 401.0.2 (2023102201)
==========================================
1. Fix 'get_userprofile_renderer' namespace.
2. Fix missing category returns.

Change log in version 401.0.1 (2023102200)
==========================================
1. First version.
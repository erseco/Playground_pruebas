<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Language.
 *
 * @package    local_adaptable
 * @copyright  2023 G J Barnard.
 * @author     G J Barnard -
 *               {@link https://moodle.org/user/profile.php?id=442195}
 *               {@link https://gjbarnard.co.uk}
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later.
 */

// phpcs:disable moodle.Files.LangFilesOrdering

// General.
$string['pluginname'] = 'Local Adaptable';

$string['missingmethods'] = 'Method(s) \'{$a->methods}\' required, please upgrade Local Adaptable to version \'{$a->versionrequired}\'.';

$string['usersettings:usersettingsmodal'] = 'Theme user settings';
$string['usersettings:mysitessortoverridetheme'] = 'Use theme setting value';
$string['usersettings:fav'] = 'Favourites';
$string['usersettings:userfavmenu'] = 'Favourites menu';
$string['usersettings:userfavmenutitle'] = 'Title';
$string['usersettings:userfavmenutitledesc'] = 'Won\'t show if the theme \'navbardisplaytitles\' setting has been unset.';
$string['usersettings:userfavmenumenu'] = 'Menu';
$string['usersettings:userfavmenumenudesc'] = 'The format of each line is \'text|url|title|langs|fontawesome classes\'.  Only enter what you require.  If you don\'t need something but do need another thing further along then leave it blank but still use the \'|\' delimiter.  For example: \'text|url|||fontawesome classes\'.  To find the FontAwesome(Free) classes for the icon you wish to use, go to <a href="https://fontawesome.com/search?o=r&m=free" target="_blank">Font Awesome free</a> and search for the icon.  You can use the name, such as \'graduation-cap\' or the complete list of classes \'fa-solid fa-graduation-cap\'.  For more information on \'langs\', please visit <a href="https://docs.moodle.org/en/Language_FAQ#What_do_codes_like_%22en%22_and_%22en_us%22_or_%22es%22_and_%22es_mx%22_and_%22es_ve%22_mean?? target="_blank">\'Language codes\'</a>.';

// Privacy.
$string['privacy:userfavmenu'] = 'User favourites menu.';
$string['privacy:userfavmenuexport'] = 'User\'s \'Favourites menu\' with the value \'{$a->value}\'.';
$string['privacy:userfavmenutitle'] = 'User favourites menu title.';
$string['privacy:userfavmenutitleexport'] = 'User\'s \'Favourites menu title\' with the value \'{$a->value}\'.';
$string['privacy:usermysitessortoverride'] = 'My courses custom sort.';
$string['privacy:usermysitessortoverrideexport'] = 'User\'s \'My courses custom sort\' with the value \'{$a->value}\' representing \'{$a->description}\'.';

<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

namespace local_accessibility\hooks\output;

/**
 * Inject the accessibility panel before the page footer is generated.
 *
 * @package    local_accessibility
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class before_footer_html_generation {
    /**
     * Callback to allow modifying footer HTML.
     *
     * @param \core\hook\output\before_footer_html_generation $hook
     */
    public static function callback(\core\hook\output\before_footer_html_generation $hook): void {
        global $OUTPUT, $PAGE;
        /** @var \core_renderer $OUTPUT */
        /** @var \moodle_page $PAGE */

        $PAGE->requires->js_call_amd('local_accessibility/panel', 'init');

        $mainbutton = $OUTPUT->render_from_template('local_accessibility/mainbutton', []);
        $panel = $OUTPUT->render_from_template('local_accessibility/panel', []);

        $hook->add_html($mainbutton . $panel);
    }
}

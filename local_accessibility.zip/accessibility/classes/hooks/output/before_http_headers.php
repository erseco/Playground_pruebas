<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

namespace local_accessibility\hooks\output;

defined('MOODLE_INTERNAL') || die();

/**
 * Load the assets required by the accessibility panel.
 *
 * @package    local_accessibility
 * @license    https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class before_http_headers {
    /**
     * Callback to allow modifying headers.
     *
     * @param \core\hook\output\before_http_headers $hook
     */
    public static function callback(\core\hook\output\before_http_headers $hook): void {
        global $PAGE;
        /** @var \moodle_page $PAGE */
        $PAGE->requires->css('/local/accessibility/styles.css');
    }
}

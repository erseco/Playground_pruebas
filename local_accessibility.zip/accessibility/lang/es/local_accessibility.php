<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * Cadenas en español del plugin.
 *
 * @package     local_accessibility
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['accessibilitywidgets'] = 'Herramientas de accesibilidad';
$string['addwidget'] = 'Añadir herramienta';
$string['manageenabledwidgets'] = 'Gestionar herramientas activadas';
$string['pluginname'] = 'Accesibilidad';
$string['privacy:metadata:configs'] = 'Configuración de una herramienta del plugin de accesibilidad';
$string['privacy:metadata:configs:configvalue'] = 'Valor de configuración utilizado';
$string['privacy:metadata:configs:userid'] = 'Usuario asignado a la configuración';
$string['privacy:metadata:configs:widget'] = 'Nombre de la herramienta';
$string['reset'] = 'Reiniciar';
$string['resetall'] = 'Reiniciar todo';
$string['subplugintype_accessibility'] = 'Herramienta de accesibilidad';
$string['subplugintype_accessibility_plural'] = 'Herramientas de accesibilidad';
$string['widget'] = 'Herramienta';

// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

/**
 * Custom accessibility panel.
 *
 * @module      local_accessibility/panel
 * @copyright   2026 Adapted for Spanish accessibility panel
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

const storeKey = 'a11yPrefs.v5';
const defaults = {
    bgColor: '',
    textColor: '',
    fontFamily: '',
    kerning: 'normal',
    fontSizeScale: 1,
    letterSpacing: 0,
    lineHeight: 1.2,
    textAlign: '',
    hideImages: false,
    linkHighlight: false,
    highContrast: false,
    preHC: null
};

let state = null;
let alreadyInitialised = false;
let lastFocus = null;
let previousBodyOverflow = '';

const load = () => {
    try {
        return Object.assign({}, defaults, JSON.parse(localStorage.getItem(storeKey) || '{}'));
    } catch (e) {
        return Object.assign({}, defaults);
    }
};

const save = () => {
    localStorage.setItem(storeKey, JSON.stringify(state));
};

const clamp = (n, min, max) => Math.min(max, Math.max(min, n));

const setVar = (name, value) => {
    document.documentElement.style.setProperty(name, value);
};

const removeElementById = id => {
    const element = document.getElementById(id);
    if (element) {
        element.remove();
    }
};

const setBodyClass = (className, enabled) => {
    document.body.classList.toggle(className, Boolean(enabled));
};

const imgToggle = hide => {
    const id = 'a11y-hide-img-style';
    let style = document.getElementById(id);
    if (hide) {
        if (!style) {
            style = document.createElement('style');
            style.id = id;
            style.textContent = 'img,picture,video,svg{visibility:hidden!important}' +
                '.a11y-btn svg,.a11y-panel svg{visibility:visible!important}';
            document.head.appendChild(style);
        }
    } else if (style) {
        style.remove();
    }
};

const linkHL = on => {
    const id = 'a11y-link-highlight-style';
    let style = document.getElementById(id);
    if (on) {
        if (!style) {
            style = document.createElement('style');
            style.id = id;
            style.textContent = 'a[href]{outline:2px solid #2563eb!important;background:#e0ecff!important;' +
                'text-decoration:underline!important;border-radius:3px;padding:1px 2px}';
            document.head.appendChild(style);
        }
    } else if (style) {
        style.remove();
    }
};

const sync = () => {
    const fs = document.getElementById('a11yFontSize');
    const fsV = document.getElementById('a11yFontSizeVal');
    const ls = document.getElementById('a11yLetterSpacing');
    const lsV = document.getElementById('a11yLetterSpacingVal');
    const lh = document.getElementById('a11yLineHeight');
    const lhV = document.getElementById('a11yLineHeightVal');
    const bg = document.getElementById('a11yBgColor');
    const tc = document.getElementById('a11yTextColor');
    const ker = document.getElementById('a11yKerningToggle');
    const img = document.getElementById('a11yImgToggle');
    const hcOn = document.getElementById('a11yHCOn');

    if (!fs || !ls || !lh || !bg || !tc || !ker || !img || !hcOn) {
        return;
    }

    fs.value = state.fontSizeScale;
    fsV.textContent = String(state.fontSizeScale);
    ls.value = state.letterSpacing;
    lsV.textContent = String(state.letterSpacing);
    lh.value = state.lineHeight;
    lhV.textContent = String(state.lineHeight);
    fs.setAttribute('aria-valuenow', String(state.fontSizeScale));
    ls.setAttribute('aria-valuenow', String(state.letterSpacing));
    lh.setAttribute('aria-valuenow', String(state.lineHeight));
    bg.value = state.bgColor || '#000000';
    tc.value = state.textColor || '#000000';

    ker.setAttribute('aria-pressed', String(state.kerning === 'none'));
    ker.textContent = state.kerning === 'none' ? 'Activar' : 'Desactivar';

    img.setAttribute('aria-pressed', String(state.hideImages));
    img.textContent = state.hideImages ? 'Mostrar imágenes' : 'Ocultar imágenes';

    document.querySelectorAll('.a11y-pill[data-font]').forEach(pill => {
        pill.setAttribute('aria-pressed', 'false');
        const value = pill.getAttribute('data-font');
        if ((state.fontFamily === '' && value === 'reset') || state.fontFamily === value) {
            pill.setAttribute('aria-pressed', 'true');
        }
    });

    document.querySelectorAll('.a11y-pill[data-links]').forEach(pill => {
        const on = pill.getAttribute('data-links') === 'on';
        pill.setAttribute('aria-pressed', String(state.highContrast ? on : on === state.linkHighlight));
    });

    document.querySelectorAll('.a11y-pill[data-align]').forEach(pill => {
    pill.setAttribute('aria-pressed', 'false');
    const value = pill.getAttribute('data-align');
    if ((state.textAlign === '' && value === 'left') || state.textAlign === value) {
        pill.setAttribute('aria-pressed', 'true');
    }
    });



    hcOn.setAttribute('aria-pressed', String(state.highContrast));
    hcOn.textContent = state.highContrast ? 'Desactivar' : 'Activar';
};

const apply = () => {
    if (state.highContrast) {
        document.documentElement.classList.add('a11y-hc');
        setVar('--a11y-bg', '#000');
        setVar('--a11y-text', '#fff');
        setVar('--a11y-fontScale', state.fontSizeScale);
        setVar('--a11y-letterSpacing', state.letterSpacing + 'em');
        setVar('--a11y-lineHeight', state.lineHeight);
        document.body.style.fontKerning = state.kerning;
        linkHL(true);
    } else {
        document.documentElement.classList.remove('a11y-hc');
        setVar('--a11y-bg', state.bgColor || '');
        setVar('--a11y-text', state.textColor || '');
        setVar('--a11y-fontScale', state.fontSizeScale);
        setVar('--a11y-letterSpacing', (state.letterSpacing || 0) + 'em');
        setVar('--a11y-lineHeight', state.lineHeight || 1.2);

        if (state.fontFamily === 'serif') {
            document.body.style.fontFamily = "Georgia, 'Times New Roman', serif";
        } else if (state.fontFamily === 'sans') {
            document.body.style.fontFamily = "system-ui,-apple-system,'Segoe UI',Roboto,Arial,'Noto Sans','Helvetica Neue',sans-serif";
        } else if (state.fontFamily === 'dys') {
            document.body.style.fontFamily = "'OpenDyslexic','Atkinson Hyperlegible',Arial,sans-serif";
        } else {
            document.body.style.fontFamily = '';
        }

        document.body.style.fontKerning = state.kerning;
        linkHL(state.linkHighlight);
    }

    document.body.style.textAlign = state.textAlign || '';

	setBodyClass('a11y-bg-active', Boolean(state.highContrast || state.bgColor));
    setBodyClass('a11y-text-active', Boolean(state.highContrast || state.textColor));
    imgToggle(state.hideImages);
    sync();
};

const clearInjected = () => {
    ['a11y-hide-img-style', 'a11y-link-highlight-style'].forEach(removeElementById);
};

const clearVars = () => {
    ['--a11y-bg', '--a11y-text', '--a11y-fontScale', '--a11y-letterSpacing', '--a11y-lineHeight'].forEach(variable => {
        document.documentElement.style.removeProperty(variable);
    });
    document.body.style.fontKerning = '';
    document.body.style.fontFamily = '';
	document.body.style.textAlign = '';
    document.body.classList.remove('a11y-bg-active', 'a11y-text-active');
};

const resetAll = () => {
    state = Object.assign({}, defaults);
    localStorage.removeItem(storeKey);
    clearInjected();
    clearVars();
    document.documentElement.classList.remove('a11y-hc');
    save();
    apply();
};

const getFocusable = panel => Array.from(
    panel.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')
).filter(element => !element.hasAttribute('disabled') && element.offsetParent !== null);

const trap = (event, panel) => {
    if (event.key !== 'Tab') {
        return;
    }
    const focusable = getFocusable(panel);
    if (!focusable.length) {
        return;
    }
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) {
        last.focus();
        event.preventDefault();
    } else if (!event.shiftKey && document.activeElement === last) {
        first.focus();
        event.preventDefault();
    }
};

const openPanel = (modal, panel) => {
    lastFocus = document.activeElement;
    previousBodyOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    modal.setAttribute('aria-hidden', 'false');
    panel.focus();
};

const closePanel = (modal, openBtn) => {
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = previousBodyOverflow || '';
    if (lastFocus && typeof lastFocus.focus === 'function') {
        lastFocus.focus();
    } else if (openBtn) {
        openBtn.focus();
    }
};

const bindEvents = () => {
    const modal = document.getElementById('a11yModal');
    const panel = document.getElementById('a11yPanel');
    const openBtn = document.getElementById('a11yToggleBtn');
    const closeBtn = document.getElementById('a11yCloseBtn');
    const resetBtn = document.getElementById('a11yResetAll');
    const bg = document.getElementById('a11yBgColor');
    const tc = document.getElementById('a11yTextColor');
    const ker = document.getElementById('a11yKerningToggle');
    const fs = document.getElementById('a11yFontSize');
    const ls = document.getElementById('a11yLetterSpacing');
    const lh = document.getElementById('a11yLineHeight');
    const img = document.getElementById('a11yImgToggle');
    const hcOn = document.getElementById('a11yHCOn');
    const hcReset = document.getElementById('a11yHCReset');

    if (!modal || !panel || !openBtn || !closeBtn || !resetBtn || !bg || !tc || !ker || !fs || !ls || !lh || !img || !hcOn || !hcReset) {
        return;
    }

    openBtn.addEventListener('click', () => openPanel(modal, panel));
    closeBtn.addEventListener('click', () => closePanel(modal, openBtn));
    modal.addEventListener('click', event => {
        if (event.target === modal) {
            closePanel(modal, openBtn);
        }
    });
    panel.addEventListener('keydown', event => trap(event, panel));
    document.addEventListener('keydown', event => {
        if (event.key === 'Escape' && modal.getAttribute('aria-hidden') === 'false') {
            closePanel(modal, openBtn);
        }
    });

    bg.addEventListener('input', event => {
        state.bgColor = event.target.value;
        save();
        apply();
    });

    tc.addEventListener('input', event => {
        state.textColor = event.target.value;
        save();
        apply();
    });

    document.querySelectorAll('.a11y-btn-sm[data-reset]').forEach(button => button.addEventListener('click', () => {
        const key = button.getAttribute('data-reset');
        if (key === 'bg') {
            state.bgColor = '';
        }
        if (key === 'textColor') {
            state.textColor = '';
        }
        if (key === 'fontSize') {
            state.fontSizeScale = 1;
        }
        if (key === 'letterSpacing') {
            state.letterSpacing = 0;
        }
        if (key === 'lineHeight') {
            state.lineHeight = 1.2;
        }
	if (key === 'textAlign') {
    	state.textAlign = '';
	}
        save();
        apply();
    }));

    document.querySelectorAll('.a11y-pill[data-font]').forEach(button => button.addEventListener('click', () => {
        const value = button.getAttribute('data-font');
        state.fontFamily = value === 'reset' ? '' : value;
        save();
        apply();
    }));

    ker.addEventListener('click', () => {
        state.kerning = state.kerning === 'none' ? 'normal' : 'none';
        save();
        apply();
    });

    fs.addEventListener('input', event => {
        state.fontSizeScale = Number(event.target.value);
        save();
        apply();
    });

    document.querySelectorAll('.a11y-btn-sm[data-step="fontSize"]').forEach(button => button.addEventListener('click', () => {
        const direction = button.getAttribute('data-dir') === '+' ? 1 : -1;
        state.fontSizeScale = clamp(Number((state.fontSizeScale + direction * 0.05).toFixed(2)), 0.8, 2);
        save();
        apply();
    }));

    ls.addEventListener('input', event => {
        state.letterSpacing = Number(event.target.value);
        save();
        apply();
    });

    document.querySelectorAll('.a11y-btn-sm[data-step="letterSpacing"]').forEach(button => button.addEventListener('click', () => {
        const direction = button.getAttribute('data-dir') === '+' ? 1 : -1;
        state.letterSpacing = clamp(Number((state.letterSpacing + direction * 0.005).toFixed(3)), 0, 0.2);
        save();
        apply();
    }));

    lh.addEventListener('input', event => {
        state.lineHeight = Number(event.target.value);
        save();
        apply();
    });

    document.querySelectorAll('.a11y-btn-sm[data-step="lineHeight"]').forEach(button => button.addEventListener('click', () => {
        const direction = button.getAttribute('data-dir') === '+' ? 1 : -1;
        state.lineHeight = clamp(Number((state.lineHeight + direction * 0.05).toFixed(2)), 1, 2);
        save();
        apply();
    }));

    img.addEventListener('click', () => {
        state.hideImages = !state.hideImages;
        save();
        apply();
    });

    document.querySelectorAll('.a11y-pill[data-links]').forEach(button => button.addEventListener('click', () => {
        state.linkHighlight = button.getAttribute('data-links') === 'on';
        save();
        apply();
    }));

    document.querySelectorAll('.a11y-pill[data-align]').forEach(button => button.addEventListener('click', () => {
    state.textAlign = button.getAttribute('data-align');
    save();
    apply();
    }));

    hcOn.addEventListener('click', () => {
        if (!state.highContrast) {
            state.preHC = {
                bgColor: state.bgColor,
                textColor: state.textColor,
                linkHighlight: state.linkHighlight
            };
            state.highContrast = true;
        } else {
            state.highContrast = false;
        }
        save();
        apply();
    });

    hcReset.addEventListener('click', () => {
        state.highContrast = false;
        if (state.preHC) {
            Object.assign(state, state.preHC);
            state.preHC = null;
        }
        save();
        apply();
    });

    resetBtn.addEventListener('click', resetAll);
};

/**
 * Initialise accessibility panel.
 */
export const init = () => {
    const initialise = () => {
        if (alreadyInitialised) {
            return;
        }
        alreadyInitialised = true;
        state = load();
        bindEvents();
        apply();
        window.__A11Y__ = {resetAll, apply, state};
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialise);
    } else {
        initialise();
    }
};
